package com.example.mangatrans

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateRemoteModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class SettingsActivity : ComponentActivity() {
    private val p by lazy { Prefs.p(this) }
    private lateinit var dictList: LinearLayout
    private lateinit var fromEt: EditText
    private lateinit var toEt: EditText
    private lateinit var countTv: TextView
    private var filter = ""
    private fun d(v: Int) = Ui.dp(this, v)

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        Dict.seed(this)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(d(16), d(28), d(16), d(40))
        }
        root.addView(TextView(this).apply { text = "الإعدادات"; textSize = 26f; setTextColor(0xFF1B1D2A.toInt()) })
        langCard(root); fontCard(root); colorCard(root); engineCard(root); modelsCard(root); dictCard(root)
        setContentView(ScrollView(this).apply { setBackgroundColor(0xFFF4F5FB.toInt()); addView(root) })
    }

    private fun note(t: String) = TextView(this).apply { text = t; textSize = 13f; setTextColor(0xFF6B6F85.toInt()); setPadding(0, d(4), 0, d(6)) }
    private fun label(t: String) = TextView(this).apply { text = t; textSize = 15f; setTextColor(0xFF1B1D2A.toInt()); setPadding(0, d(8), 0, 0) }

    private fun spinner(m: Map<String, String>, key: String, def: String) = Spinner(this).apply {
        val keys = m.keys.toList()
        adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, m.values.toList())
        setSelection(keys.indexOf(p.getString(key, def)).coerceAtLeast(0))
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, id: Long) { p.edit().putString(key, keys[i]).apply() }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
    }

    private fun radios(opts: List<String>, key: String, def: Int, horizontal: Boolean) = RadioGroup(this).apply {
        orientation = if (horizontal) RadioGroup.HORIZONTAL else RadioGroup.VERTICAL
        val ids = opts.map { o -> RadioButton(this@SettingsActivity).apply { text = o; id = View.generateViewId() }.also { addView(it) }.id }
        check(ids[p.getInt(key, def).coerceIn(0, ids.size - 1)])
        setOnCheckedChangeListener { _, id -> p.edit().putInt(key, ids.indexOf(id)).apply() }
    }

    private fun langCard(root: LinearLayout) {
        val c = Ui.card(this, "اللغة")
        c.addView(label("لغة النص الأصلي"))
        c.addView(spinner(Prefs.sources, "src", "auto"))
        c.addView(label("الترجمة إلى"))
        c.addView(spinner(Prefs.targets, "tgt", "ar"))
        root.addView(c)
    }

    private fun fontCard(root: LinearLayout) {
        val c = Ui.card(this, "حجم خط الترجمة")
        c.addView(radios(listOf("صغير", "متوسط", "كبير"), "size", 1, true))
        root.addView(c)
    }

    private fun colorCard(root: LinearLayout) {
        val c = Ui.card(this, "لون خط الترجمة")
        c.addView(note("«A» = تلقائي: يطابق لون النص الأصلي في الصفحة"))
        val cols = listOf(0, 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD60A.toInt(), 0xFFFF3B30.toInt(), 0xFF0A84FF.toInt())
        val row = LinearLayout(this)
        fun draw() {
            row.removeAllViews()
            val cur = p.getInt("color", 0)
            cols.forEach { col ->
                row.addView(TextView(this).apply {
                    text = if (col == 0) "A" else ""; gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.BLACK)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (col == 0) 0xFFE0E3F0.toInt() else col)
                        setStroke(if (cur == col) 8 else 2, if (cur == col) Ui.ACCENT else 0xFFBBBBBB.toInt())
                    }
                    layoutParams = LinearLayout.LayoutParams(d(44), d(44)).apply { marginEnd = d(10) }
                    setOnClickListener { p.edit().putInt("color", col).apply(); draw() }
                })
            }
        }
        draw()
        c.addView(row)
        root.addView(c)
    }

    private fun engineCard(root: LinearLayout) {
        val c = Ui.card(this, "محرك الترجمة")
        c.addView(radios(listOf("على الجهاز (سريع، يعمل بدون إنترنت)",
            "جودة أعلى عبر Google Cloud (يحتاج إنترنت ومفتاح API)"), "engine", 0, false))
        c.addView(EditText(this).apply {
            hint = "مفتاح Google Cloud Translation API"; setText(p.getString("apikey", ""))
            setSingleLine(); doAfterTextChanged { p.edit().putString("apikey", it.toString()).apply() }
        })
        c.addView(note("إن فشل الاتصال أو كان المفتاح فارغاً يعود التطبيق للترجمة على الجهاز تلقائياً."))
        root.addView(c)
    }

    private fun modelsCard(root: LinearLayout) {
        val c = Ui.card(this, "اللغات دون إنترنت")
        c.addView(note("حمّل اللغة المصدر واللغة الهدف معاً (مثلاً: اليابانية + العربية) لتعمل الترجمة بسرعة وبدون إنترنت."))
        val mgr = RemoteModelManager.getInstance()
        val names = LinkedHashMap<String, String>().apply {
            putAll(Prefs.targets); Prefs.sources.forEach { if (it.key != "auto") putIfAbsent(it.key, it.value) }
        }
        names.forEach { (code, name) ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, d(6), 0, d(6)) }
            val label = TextView(this).apply { text = name; textSize = 16f; layoutParams = LinearLayout.LayoutParams(0, -2, 1f) }
            val b = TextView(this).apply { textSize = 14f; setPadding(d(14), d(8), d(14), d(8)); setTextColor(Color.WHITE) }
            val model = TranslateRemoteModel.Builder(code).build()
            fun refresh() {
                lifecycleScope.launch {
                    val ok = try { mgr.isModelDownloaded(model).await() } catch (e: Exception) { false }
                    b.text = if (ok) "✓ محمّلة · حذف" else "تحميل"
                    b.background = Ui.round(if (ok) 0xFF2EB67D.toInt() else Ui.ACCENT, 40f)
                    b.setOnClickListener {
                        lifecycleScope.launch {
                            b.text = "جارٍ..."
                            try {
                                if (ok) mgr.deleteDownloadedModel(model).await()
                                else mgr.download(model, DownloadConditions.Builder().build()).await()
                            } catch (e: Exception) {
                                Toast.makeText(this@SettingsActivity, "فشل: تحقق من الإنترنت", Toast.LENGTH_SHORT).show()
                            }
                            refresh()
                        }
                    }
                }
            }
            refresh()
            row.addView(label); row.addView(b); c.addView(row)
        }
        root.addView(c)
    }

    private fun dictCard(root: LinearLayout) {
        val c = Ui.card(this, "القاموس المخصص")
        c.addView(note("يستبدل كلمات في الترجمة العربية بما تريد، ويعمل عند الترجمة إلى العربية. اضغط على أي عبارة لتعديلها، أو ✕ لحذفها."))
        fromEt = EditText(this).apply { hint = "الكلمة في الترجمة (مثال: إله)" }
        toEt = EditText(this).apply { hint = "البديل (مثال: حاكم)" }
        c.addView(fromEt); c.addView(toEt)
        c.addView(Ui.btn(this, "إضافة / تحديث").apply {
            setOnClickListener {
                val a = fromEt.text.toString().trim(); val b = toEt.text.toString().trim()
                if (a.isNotEmpty() && b.isNotEmpty()) {
                    val m = Dict.load(context); m[a] = b; Dict.save(context, m)
                    fromEt.text.clear(); toEt.text.clear(); refreshDict()
                }
            }
        })
        c.addView(Ui.btn(this, "إضافة القاموس الجاهز (الشرك والعبادة)", false).apply {
            setOnClickListener { addPreset(Presets.core) }
        })
        c.addView(Ui.btn(this, "إضافة مجموعة السحر والسحرة (اختيارية)", false).apply {
            setOnClickListener { addPreset(Presets.magic) }
        })
        c.addView(Ui.btn(this, "حذف كل العبارات", false).apply {
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity).setMessage("حذف كل العبارات؟")
                    .setPositiveButton("حذف") { _, _ -> Dict.save(context, emptyMap()); refreshDict() }
                    .setNegativeButton("إلغاء", null).show()
            }
        })
        countTv = note("")
        c.addView(countTv)
        c.addView(EditText(this).apply {
            hint = "بحث في العبارات"; setSingleLine()
            doAfterTextChanged { filter = it.toString().trim(); refreshDict() }
        })
        dictList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        c.addView(dictList)
        root.addView(c)
        refreshDict()
    }

    private fun addPreset(preset: Map<String, String>) {
        val m = Dict.load(this)
        var n = 0
        preset.forEach { (k, v) -> if (!m.containsKey(k)) { m[k] = v; n++ } }
        Dict.save(this, m)
        refreshDict()
        Toast.makeText(this, "أُضيفت $n عبارة", Toast.LENGTH_SHORT).show()
    }

    private fun refreshDict() {
        dictList.removeAllViews()
        val all = Dict.load(this)
        countTv.text = "عدد العبارات: ${all.size}"
        for ((k, v) in all) {
            if (filter.isNotEmpty() && !k.contains(filter) && !v.contains(filter)) continue
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply {
                text = "$k  ←  $v"; textSize = 17f; setPadding(0, d(8), 0, d(8))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { fromEt.setText(k); toEt.setText(v) }
            })
            row.addView(TextView(this).apply {
                text = "✕"; textSize = 18f; setTextColor(0xFFFF3B30.toInt()); setPadding(d(14), d(8), d(14), d(8))
                setOnClickListener { val m = Dict.load(context); m.remove(k); Dict.save(context, m); refreshDict() }
            })
            dictList.addView(row)
        }
    }
}
