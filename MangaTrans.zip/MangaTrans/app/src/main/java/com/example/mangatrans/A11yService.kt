package com.example.mangatrans

import android.accessibilityservice.AccessibilityService
import android.content.Intent
import android.view.accessibility.AccessibilityEvent

/**
 * خدمة فارغة الغرض منها واحد: نوافذ إمكانية الوصول (TYPE_ACCESSIBILITY_OVERLAY) موثوقة،
 * فلا يحدّ أندرويد من شفافيتها، وبذلك تغطي النص الأصلي بالكامل. لا تقرأ أي محتوى.
 */
class A11yService : AccessibilityService() {
    companion object { @Volatile var instance: A11yService? = null }

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(e: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onUnbind(i: Intent?): Boolean { instance = null; return super.onUnbind(i) }
    override fun onDestroy() { instance = null; super.onDestroy() }
}
