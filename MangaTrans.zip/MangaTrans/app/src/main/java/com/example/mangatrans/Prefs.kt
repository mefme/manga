package com.example.mangatrans

import android.content.Context

object Prefs {
    fun p(c: Context) = c.getSharedPreferences("p", 0)
    val sources = linkedMapOf(
        "auto" to "تلقائي", "en" to "الإنجليزية", "ja" to "اليابانية", "ko" to "الكورية",
        "zh" to "الصينية", "fr" to "الفرنسية", "es" to "الإسبانية", "de" to "الألمانية",
        "it" to "الإيطالية", "pt" to "البرتغالية"
    )
    val targets = linkedMapOf("ar" to "العربية", "en" to "الإنجليزية", "fr" to "الفرنسية")
}
