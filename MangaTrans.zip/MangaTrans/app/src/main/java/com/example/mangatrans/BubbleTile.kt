package com.example.mangatrans

import android.app.PendingIntent
import android.content.Intent
import android.os.Build
import android.service.quicksettings.Tile
import android.service.quicksettings.TileService

/** بلاطة في الإعدادات السريعة: تشغّل الفقاعة أو توقفها بضغطة. */
class BubbleTile : TileService() {
    override fun onStartListening() { refresh() }

    override fun onClick() {
        if (Prefs.p(this).getBoolean("running", false)) {
            startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        } else {
            val i = Intent(this, ProjectionActivity::class.java).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            if (Build.VERSION.SDK_INT >= 34) {
                startActivityAndCollapse(PendingIntent.getActivity(this, 0, i, PendingIntent.FLAG_IMMUTABLE))
            } else {
                @Suppress("DEPRECATION")
                startActivityAndCollapse(i)
            }
        }
        refresh()
    }

    private fun refresh() {
        qsTile?.let {
            it.state = if (Prefs.p(this).getBoolean("running", false)) Tile.STATE_ACTIVE else Tile.STATE_INACTIVE
            it.updateTile()
        }
    }
}
