package com.example.mangatrans

import android.content.Context
import org.json.JSONObject

/** القاموس المخصص: يُطبَّق على النص العربي الناتج عن الترجمة. */
object Dict {
    fun load(c: Context): LinkedHashMap<String, String> {
        val o = JSONObject(c.getSharedPreferences("p", 0).getString("dict", "{}")!!)
        val m = LinkedHashMap<String, String>()
        o.keys().forEach { m[it] = o.getString(it) }
        return m
    }

    fun save(c: Context, m: Map<String, String>) {
        c.getSharedPreferences("p", 0).edit().putString("dict", JSONObject(m).toString()).apply()
    }

    // يطابق الكلمة مع السوابق (و ف ب ك ل ال) ويتجاهل اختلاف الهمزات
    fun fix(text: String, m: Map<String, String>): String {
        var t = text
        for ((k, v) in m.entries.sortedByDescending { it.key.length }) {
            val key = k.map { if (it in "أإآا") "[أإآا]" else Regex.escape(it.toString()) }.joinToString("")
            val r = Regex("(?<!\\p{L})([وفبكل]?(?:ال)?)$key(?!\\p{L})")
            t = r.replace(t) { it.groupValues[1] + v }
        }
        return t
    }
}
