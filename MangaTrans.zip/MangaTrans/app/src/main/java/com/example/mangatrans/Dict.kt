package com.example.mangatrans

import android.content.Context
import org.json.JSONObject

/** القاموس المخصص: يُطبَّق على النص العربي الناتج عن الترجمة. */
object Dict {
    fun seed(c: Context) {
        val p = c.getSharedPreferences("p", 0)
        if (!p.getBoolean("seeded2", false)) {
            val m = load(c)
            Presets.core.forEach { (k, v) -> if (!m.containsKey(k)) m[k] = v }
            save(c, m)
            p.edit().putBoolean("seeded2", true).apply()
        }
    }

    fun load(c: Context): LinkedHashMap<String, String> {
        val o = JSONObject(c.getSharedPreferences("p", 0).getString("dict", "{}")!!)
        val m = LinkedHashMap<String, String>()
        o.keys().forEach { m[it] = o.getString(it) }
        return m
    }

    fun toJson(m: Map<String, String>): JSONObject {
        val o = JSONObject()
        for ((k, v) in m) o.put(k, v)
        return o
    }

    fun save(c: Context, m: Map<String, String>) {
        c.getSharedPreferences("p", 0).edit().putString("dict", toJson(m).toString()).apply()
    }

    private fun norm(s: String) = s.replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا')

    /**
     * استبدال في مرور واحد (بدون تسلسل)، الأطول أولاً.
     * يتعامل مع السوابق (و ف ب ك ل ال) ويتجاهل اختلاف الهمزات.
     */
    fun fix(text: String, m: Map<String, String>): String {
        val keys = m.keys.map { it.trim() }.filter { it.isNotEmpty() }
        if (keys.isEmpty()) return text
        val map = HashMap<String, String>()
        m.forEach { (k, v) -> map[norm(k.trim())] = v }
        val alt = keys.sortedByDescending { it.length }.joinToString("|") { k ->
            k.map { ch -> if (ch in "أإآا") "[أإآا]" else Regex.escape(ch.toString()) }.joinToString("")
        }
        val r = Regex("(?<!\\p{L})([وفبكل]?(?:ال)?)($alt)(?!\\p{L})")
        return r.replace(text) { mr ->
            val v = map[norm(mr.groupValues[2])]
            if (v == null) mr.value else mr.groupValues[1] + v
        }
    }
}
