package com.example.mangatrans

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View

/** lines: مستطيلات أسطر النص الأصلي مع لون الخلفية المحيطة بكل سطر (للتمويه). */
class Item(val lines: List<Pair<RectF, Int>>, val box: RectF, val text: String, val fg: Int, val scale: Float)

class TranslationOverlayView(c: Context) : View(c) {
    private var items: List<Item> = emptyList()
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG)
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }

    fun setItems(l: List<Item>) { items = l; invalidate() }
    fun hasItems() = items.isNotEmpty()

    private fun layout(t: String, w: Int) =
        StaticLayout.Builder.obtain(t, 0, t.length, tp, w)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL).build()

    override fun onDraw(c: Canvas) {
        for (m in items) {
            // 1) تمويه النص الأصلي بلون الخلفية المأخوذ من حوله (فيبقى شكل الفقاعة والرسم)
            for ((r, col) in m.lines) { fill.color = col; c.drawRoundRect(r, 8f, 8f, fill) }
            // 2) ملاءمة حجم الخط
            val avgH = m.lines.map { it.first.height() }.average().toFloat()
            val bw = (m.box.width() + 24f).coerceAtLeast(160f)
            val tw = bw.toInt()
            var size = (avgH * 0.95f).coerceIn(22f, 70f)
            var sl: StaticLayout
            do {
                tp.textSize = size
                sl = layout(m.text, tw)
                size -= 2f
            } while (sl.height > m.box.height() * 1.2f && size > 18f)
            val finalSize = ((size + 2f) * m.scale).coerceAtLeast(16f)
            tp.textSize = finalSize
            sl = layout(m.text, tw)
            // 3) رسم النص مع حد خفيف بلون الخلفية ليبقى مقروءاً
            val halo = m.lines.first().second
            c.save()
            c.translate(m.box.centerX() - bw / 2, m.box.centerY() - sl.height / 2f)
            tp.style = Paint.Style.STROKE; tp.strokeWidth = finalSize * 0.2f; tp.color = halo
            sl.draw(c)
            tp.style = Paint.Style.FILL; tp.color = m.fg
            sl.draw(c)
            c.restore()
        }
    }
}
