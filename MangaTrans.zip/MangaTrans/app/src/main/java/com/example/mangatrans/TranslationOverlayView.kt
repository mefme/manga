package com.example.mangatrans

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View

class TranslationOverlayView(c: Context) : View(c) {
    private var items: List<Pair<RectF, String>> = emptyList()
    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.argb(242, 255, 255, 255) }
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.BLACK; typeface = Typeface.DEFAULT_BOLD }

    fun setItems(l: List<Pair<RectF, String>>) { items = l; invalidate() }
    fun hasItems() = items.isNotEmpty()

    private fun build(t: String, w: Int) =
        StaticLayout.Builder.obtain(t, 0, t.length, tp, w)
            .setAlignment(Layout.Alignment.ALIGN_CENTER)
            .setTextDirection(TextDirectionHeuristics.RTL).build()

    override fun onDraw(c: Canvas) {
        for ((r, t) in items) {
            val pad = 8f
            val bw = (r.width() + pad * 4).coerceAtLeast(120f)
            val tw = (bw - pad * 2).toInt()
            var size = (r.height() * 0.45f).coerceIn(24f, 60f)
            var sl: StaticLayout
            do {
                tp.textSize = size
                sl = build(t, tw)
                size -= 2f
            } while (sl.height > r.height() && size > 20f)
            val bh = maxOf(r.height(), sl.height + pad * 2)
            val box = RectF(r.centerX() - bw / 2, r.centerY() - bh / 2, r.centerX() + bw / 2, r.centerY() + bh / 2)
            c.drawRoundRect(box, 16f, 16f, bg)
            c.save()
            c.translate(box.left + pad, r.centerY() - sl.height / 2f)
            sl.draw(c)
            c.restore()
        }
    }
}
