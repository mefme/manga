package com.example.mangatrans

import android.content.Intent
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import android.provider.Settings
import android.net.Uri
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

/** تُفتح من البلاطة أو الاختصار، وتطلب إذن التقاط الشاشة ثم تشغّل الفقاعة. */
class ProjectionActivity : ComponentActivity() {
    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", data))
        }
        finish()
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» أولاً", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            finish()
            return
        }
        capture.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}
