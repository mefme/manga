package com.example.mangatrans

import android.content.Context
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    val ACCENT = 0xFF5B6CFF.toInt()
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun round(color: Int, r: Float = 28f, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = r; if (stroke != 0) setStroke(3, stroke)
    }
    fun btn(c: Context, t: String, filled: Boolean = true) = TextView(c).apply {
        text = t; textSize = 17f; gravity = Gravity.CENTER
        setTextColor(if (filled) Color.WHITE else ACCENT)
        background = round(if (filled) ACCENT else Color.WHITE, 40f, if (filled) 0 else ACCENT)
        setPadding(0, dp(c, 16), 0, dp(c, 16))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 12) }
    }
    fun card(c: Context, title: String) = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = round(Color.WHITE, 36f)
        setPadding(dp(c, 18), dp(c, 14), dp(c, 18), dp(c, 14))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 14) }
        addView(TextView(c).apply { text = title; textSize = 18f; setTextColor(ACCENT); setPadding(0, 0, 0, dp(c, 8)) })
    }
}
