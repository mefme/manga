package com.example.mangatrans

import android.content.Context
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.widget.LinearLayout
import android.widget.TextView

object Ui {
    const val ACCENT = 0xFF5B6CFF.toInt()
    fun dp(c: Context, v: Int) = (v * c.resources.displayMetrics.density).toInt()
    fun color(c: Context, id: Int) = c.getColor(id)

    fun round(color: Int, r: Float = 28f, stroke: Int = 0) = GradientDrawable().apply {
        setColor(color); cornerRadius = r; if (stroke != 0) setStroke(3, stroke)
    }

    fun btn(c: Context, t: String, filled: Boolean = true) = TextView(c).apply {
        text = t; textSize = 16f; gravity = Gravity.CENTER
        typeface = Typeface.DEFAULT_BOLD
        setTextColor(if (filled) 0xFFFFFFFF.toInt() else ACCENT)
        background = round(if (filled) ACCENT else color(c, R.color.surface), 40f, if (filled) 0 else ACCENT)
        setPadding(0, dp(c, 15), 0, dp(c, 15))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 12) }
    }

    fun card(c: Context, heading: String): LinearLayout = LinearLayout(c).apply {
        orientation = LinearLayout.VERTICAL
        background = round(color(c, R.color.surface), 32f)
        setPadding(dp(c, 18), dp(c, 16), dp(c, 18), dp(c, 18))
        layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = dp(c, 14) }
        addView(TextView(c).apply {
            text = heading; textSize = 17f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(color(c, R.color.text))
        })
    }

    fun note(c: Context, t: String) = TextView(c).apply {
        text = t; textSize = 13f; setTextColor(color(c, R.color.subtext))
        setPadding(0, dp(c, 6), 0, dp(c, 6))
    }
}
