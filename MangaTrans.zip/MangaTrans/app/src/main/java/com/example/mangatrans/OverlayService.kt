package com.example.mangatrans

import android.app.*
import android.content.ComponentCallbacks
import android.content.res.Configuration
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.*
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

@Suppress("DEPRECATION")
class OverlayService : Service() {
    companion object { const val ACTION_STOP = "com.example.mangatrans.STOP" }

    private class Analysis(val patch: Bitmap, val items: List<Item>, val origs: List<String>)

    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private lateinit var overlay: TranslationOverlayView
    private lateinit var watcher: View
    private lateinit var bar: FrameLayout
    private lateinit var capsule: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var handle: ImageView
    private lateinit var dot: View
    private lateinit var barLp: LP
    private lateinit var snapBtn: ImageView
    private lateinit var autoBtn: ImageView
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var auto: Job? = null
    @Volatile private var busy = false
    @Volatile private var gen = 0            // يزداد عند كل لمسة على الشاشة
    @Volatile private var collapsed = false   // الفقاعة منطوية على الحافة
    private var edge = 0                       // 0 يسار، 1 يمين، 2 أعلى، 3 أسفل
    private var expW = 0                       // عرض الفقاعة المفتوحة
    private lateinit var overlayLp: LP
    private lateinit var watcherLp: LP
    private var sf = 1f
    private var alphaPct = 100
    private var w = 0
    private var h = 0
    private var cached: Bitmap? = null
    private var detected: String? = null
    private val cache = HashMap<String, String>()

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val ja by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val zh by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val langId by lazy { LanguageIdentification.getClient() }
    private val translators = HashMap<String, Translator>()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        registerComponentCallbacks(object : ComponentCallbacks {
            override fun onConfigurationChanged(c: Configuration) { main.postDelayed({ updateScreenSize() }, 250) }
            override fun onLowMemory() {}
        })
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (proj != null || i == null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("c", "MangaTrans", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "c")
            .setContentTitle("مترجم المانهوا يعمل")
            .setContentText("الفقاعة تعمل فوق التطبيقات")
            .setSmallIcon(R.drawable.ic_translate)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data: Intent = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)!!
        else i.getParcelableExtra("data")!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        Prefs.p(this).edit().putBoolean("running", true).apply()
        buildUi()
        scope.launch {
            while (isActive) {
                delay(500)
                updateScreenSize()
                try { withContext(Dispatchers.Main) { ensureAttached() } } catch (_: Exception) {}
            }
        }
        return START_NOT_STICKY
    }

    // ---------------- الواجهة العائمة ----------------
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun circle(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun ripple(bg: Int) = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), circle(bg), null)
    private fun icon(res: Int, bg: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(Color.WHITE)
        setPadding(bd(10), bd(10), bd(10), bd(10))
        background = ripple(bg)
        layoutParams = LinearLayout.LayoutParams(bd(42), bd(42)).apply { marginStart = bd(4) }
        isClickable = true
    }
    private fun tap(v: View) = v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
    private fun bd(v: Int) = Ui.dp(this, (v * sf).toInt())
    private fun barColor() = ((alphaPct * 255 / 100) shl 24) or 0x17181F

    private fun buildUi() {
        val t = LP.TYPE_APPLICATION_OVERLAY
        val prefs = Prefs.p(this)
        sf = prefs.getInt("bscale", 100).coerceIn(60, 140) / 100f
        alphaPct = prefs.getInt("balpha2", 100).coerceIn(20, 100)
        overlay = TranslationOverlayView(this)
        overlayLp = LP(w, h, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(overlay, overlayLp)

        // مستشعر اللمس: نافذة صغيرة ترى اللمسات الخارجية دون أن تمنعها عن التطبيق
        watcher = object : View(this@OverlayService) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_OUTSIDE && auto != null) onScreenTouched()
                return false
            }
        }
        watcherLp = LP(1, 1, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_WATCH_OUTSIDE_TOUCH or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START }
        wm.addView(watcher, watcherLp)

        handle = ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(bd(11), bd(11), bd(11), bd(11))
            background = circle(Ui.ACCENT)
            layoutParams = LinearLayout.LayoutParams(bd(46), bd(46))
        }
        dot = View(this).apply {
            background = circle(0xFF8E8E93.toInt())
            layoutParams = LinearLayout.LayoutParams(bd(8), bd(8)).apply { marginStart = bd(6); marginEnd = bd(4) }
        }
        snapBtn = icon(R.drawable.ic_eye, 0x33FFFFFF)     // لقطة شاشة مترجمة قابلة للنسخ
        autoBtn = icon(R.drawable.ic_play, 0x33FFFFFF)    // ترجمة مستمرة
        val closeBtn = icon(R.drawable.ic_close, 0x33FF3B30)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(snapBtn); addView(autoBtn); addView(closeBtn)
        }
        capsule = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(barColor(), bd(40).toFloat())
            setPadding(bd(5), bd(5), bd(6), bd(5))
            addView(handle); addView(dot); addView(panel)
        }
        bar = FrameLayout(this).apply {
            addView(capsule, FrameLayout.LayoutParams(-2, -2, Gravity.CENTER_VERTICAL or Gravity.START))
        }
        capsule.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        expW = capsule.measuredWidth
        barLp = LP(expW, LP.WRAP_CONTENT, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = bd(6); y = h / 3 }
        wm.addView(bar, barLp)
        if (false) capsule.addOnLayoutChangeListener { v, _, _, _, _, _, _, _, _ ->
            // إيماءات النظام (الرجوع والتنقل) تقطع السحب قرب الحافة، فنستثني منطقة الفقاعة منها
            try { if (Build.VERSION.SDK_INT >= 29) v.systemGestureExclusionRects = listOf(Rect(0, 0, v.width, v.height)) } catch (_: Exception) {}
        }

        // السحب يحرك الكبسولة، والضغطة القصيرة تطويها أو تفتحها، وعند الإفلات تلتصق بالحافة
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false; var pendingMove = false
        handle.setOnTouchListener { _, e ->
            try { when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = barLp.x; oy = barLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) {
                        barLp.x = (ox + dx.toInt()).coerceIn(-barLp.width, w)
                        barLp.y = (oy + dy.toInt()).coerceIn(0, (h - bar.height).coerceAtLeast(0))
                        if (!pendingMove) { pendingMove = true; handle.postOnAnimation { pendingMove = false; updateBar() } }
                    }
                }
                MotionEvent.ACTION_CANCEL -> {
                    // إن قاطع النظام اللمسة (مثل إيماءة الحافة) نثبّت الفقاعة حيث وصلت
                    if (moved) { if (collapsed) snapCollapsed() else snapToEdge() }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        tap(handle)
                        if (collapsed) expandFromEdge()
                        else if (auto != null) collapseToEdge()
                        else {
                            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            placeExpanded(edge)
                        }
                    } else {
                        if (collapsed) snapCollapsed() else snapToEdge()
                    }
                }
            } } catch (_: Exception) {}
            true
        }
        snapBtn.setOnClickListener {
            tap(it)
            if (overlay.hasItems()) overlay.clear()
            else scope.launch { pass(); if (overlay.hasItems() && auto == null) watchMotion() }
        }
        autoBtn.setOnClickListener { tap(it); toggleAuto() }
        closeBtn.setOnClickListener { stopSelf() }
        refreshStatus()
    }

    private fun barWidth(): Int {
        bar.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        return bar.measuredWidth
    }

    private fun updateBar() {
        try { if (bar.isAttachedToWindow) wm.updateViewLayout(bar, barLp) } catch (_: Exception) {}
    }

    private fun barSize(): Pair<Int, Int> {
        capsule.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        return capsule.measuredWidth to capsule.measuredHeight
    }

    /** أقرب حافة من الأربع إلى مركز الفقاعة. */
    private fun nearestEdge(): Int {
        val (cw, _) = barSize()
        val capLeft = if (edge == 1) barLp.x + barLp.width - cw else barLp.x
        return if (capLeft + cw / 2 < w / 2) 0 else 1
    }

    /** ترتيب عناصر الفقاعة: عند اليمين تفتح الخيارات من اليمين إلى اليسار. */
    private var arrangedRight = false

    private fun arrangeBar(rightSide: Boolean) {
        if (rightSide == arrangedRight) return
        arrangedRight = rightSide
        // لا نعيد ترتيب العناصر أثناء معالجة اللمس، بل بعد انتهائها
        main.post {
            try {
                capsule.removeAllViews()
                if (rightSide) { capsule.addView(panel); capsule.addView(dot); capsule.addView(handle) }
                else { capsule.addView(handle); capsule.addView(dot); capsule.addView(panel) }
                capsule.layoutParams = FrameLayout.LayoutParams(-2, -2,
                    Gravity.CENTER_VERTICAL or (if (rightSide) Gravity.END else Gravity.START))
                updateBar()
            } catch (_: Exception) {}
        }
    }

    private fun placeExpanded(e: Int) {
        edge = e
        arrangeBar(e == 1)
        capsule.setPadding(bd(5), bd(5), bd(6), bd(5))
        barLp.width = expW
        barLp.height = LP.WRAP_CONTENT
        barLp.x = if (e == 0) bd(6) else w - bd(6) - expW
        val (_, bh) = barSize()
        barLp.y = barLp.y.coerceIn(bd(8), (h - bh - bd(8)).coerceAtLeast(bd(8)))
        updateBar()
    }

    /** السهم المطوي: نافذته بحجم الأيقونة تماماً، بلا حشوة ولا هوامش. */
    private fun placeCollapsed(e: Int) {
        edge = e
        arrangeBar(e == 1)
        capsule.setPadding(0, 0, 0, 0)
        val size = bd(46)
        barLp.width = size
        barLp.height = size
        barLp.x = if (e == 0) -bd(18) else w + bd(18) - size
        barLp.y = barLp.y.coerceIn(0, (h - size).coerceAtLeast(0))
        handle.rotation = if (e == 0) 0f else 180f
        updateBar()
    }

    private fun snapToEdge() { placeExpanded(nearestEdge()) }

    /** طيّ الفقاعة إلى سهم صغير على أقرب حافة (يُستخدم أثناء الترجمة المستمرة فقط). */
    private fun collapseToEdge() {
        if (collapsed) return
        val e = nearestEdge()
        panel.visibility = View.GONE; dot.visibility = View.GONE
        handle.setImageResource(R.drawable.ic_chevron)
        collapsed = true
        placeCollapsed(e)
    }

    /** تحريك السهم المطوي إلى حافة أخرى دون فتحه. */
    private fun snapCollapsed() { placeCollapsed(nearestEdge()) }

    /** إخراج الفقاعة من الحافة إلى وضعها الكامل. */
    private fun expandFromEdge() {
        collapsed = false
        handle.setImageResource(R.drawable.ic_translate); handle.rotation = 0f
        dot.visibility = View.VISIBLE; panel.visibility = View.VISIBLE
        placeExpanded(edge)
    }

    /** يتحقق أن نوافذ الفقاعة ما زالت ظاهرة، ويعيد إضافة أي نافذة اختفت. */
    private fun ensureAttached() {
        try {
            if (!overlay.isAttachedToWindow) wm.addView(overlay, overlayLp)
            if (!watcher.isAttachedToWindow) wm.addView(watcher, watcherLp)
            if (!bar.isAttachedToWindow) {
                wm.addView(bar, barLp)
                if (collapsed) placeCollapsed(edge) else placeExpanded(edge)
            }
        } catch (_: Exception) {}
    }

    /** عند تدوير الشاشة: تحديث أبعاد الالتقاط والطبقات وإعادة الفقاعة إلى حافتها. */
    private fun screenSize(): Pair<Int, Int> {
        if (Build.VERSION.SDK_INT >= 30) {
            val b = wm.currentWindowMetrics.bounds
            return b.width() to b.height()
        }
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        return dm.widthPixels to dm.heightPixels
    }

    private fun updateScreenSize() {
        val (sw, sh) = screenSize()
        if (sw == w && sh == h) return
        w = sw; h = sh
        val dm = DisplayMetrics()
        @Suppress("DEPRECATION")
        wm.defaultDisplay.getRealMetrics(dm)
        cached = null
        reader?.close()
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd?.resize(w, h, dm.densityDpi)
        vd?.setSurface(reader!!.surface)
        main.post {
            try {
                overlay.clear()
                overlayLp.width = w; overlayLp.height = h
                if (overlay.isAttachedToWindow) wm.updateViewLayout(overlay, overlayLp)
                if (collapsed) placeCollapsed(edge) else placeExpanded(edge)
            } catch (_: Exception) {}
        }
    }

    private fun refreshStatus() {
        main.post {
            val running = auto != null
            dot.background = circle(when {
                busy -> 0xFFFFC107.toInt()
                running -> 0xFF2EB67D.toInt()
                else -> 0xFF8E8E93.toInt()
            })
            autoBtn.setImageResource(if (running) R.drawable.ic_pause else R.drawable.ic_play)
            autoBtn.background = ripple(if (running) 0xFF2EB67D.toInt() else 0x33FFFFFF)
        }
    }

    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    private var motion: Job? = null

    /** يراقب الشاشة بعد الترجمة اليدوية، ويخفيها فور بدء التحريك. */
    private fun watchMotion() {
        motion?.cancel()
        motion = scope.launch {
            delay(700)   // انتظر حتى تظهر الترجمة في الالتقاط، وإلا تُقارَن الصورة بدونها فتختفي فوراً
            var base: IntArray? = grab()?.let { sig(it) }
            while (isActive && overlay.hasItems()) {
                delay(120)
                val cur = grab()?.let { sig(it) } ?: continue
                if (base == null) { base = cur; continue }
                if (diff(base!!, cur) > 3) { main.post { overlay.clear() }; break }
            }
        }
    }

    /** لمسة على الشاشة أثناء الترجمة المستمرة: إخفاء فوري ثم إعادة الترجمة عند توقف الحركة. */
    private fun onScreenTouched() {
        gen++
        main.post { overlay.clear() }
    }

    private fun toggleAuto() {
        if (auto != null) {
            auto?.cancel(); auto = null
            if (collapsed) expandFromEdge()
            refreshStatus()
            return
        }
        collapseToEdge()
        auto = scope.launch {
            var prev: IntArray? = null
            var done: IntArray? = null
            var seen = gen
            while (isActive) {
                delay(220)
                updateScreenSize()
                if (gen != seen) { seen = gen; prev = null; done = null; continue }
                if (busy) continue
                val s = sig(grab() ?: continue)
                val moving = prev == null || diff(prev!!, s) > 3
                prev = s
                if (done != null && diff(done!!, s) <= 4) continue
                if (overlay.hasItems()) main.post { overlay.clear() }
                if (moving) continue
                pass()
                delay(120)
                done = grab()?.let { sig(it) }
            }
        }
        refreshStatus()
    }

    private suspend fun pass() {
        if (busy) return
        busy = true
        val myGen = gen
        refreshStatus()
        try {
            updateScreenSize()
            withContext(Dispatchers.Main) { overlay.clear() }
            val bmp = grabFresh() ?: return
            val a = analyze(bmp) ?: return
            if (gen != myGen) return           // المستخدم لمس الشاشة أثناء المعالجة، فنتجاهل النتيجة
            withContext(Dispatchers.Main) {
                overlay.show(a.patch, a.items)
            }
        } finally {
            busy = false
            refreshStatus()
        }
    }

    // ---------------- خط المعالجة ----------------
    private fun recognizer(src: String) = when (src) { "ja" -> ja; "ko" -> ko; "zh" -> zh; else -> latin }

    private suspend fun detect(bmp: Bitmap): String {
        val img = InputImage.fromBitmap(bmp, 0)
        val lt = latin.process(img).await().text
        if (lt.count { it in 'A'..'Z' || it in 'a'..'z' || it in 'À'..'ÿ' } >= 10) {
            val code = try { langId.identifyLanguage(lt.replace('\n', ' ')).await() } catch (e: Exception) { "und" }
            return if (code in setOf("en", "fr", "es", "de", "it", "pt")) code else "en"
        }
        if (ja.process(img).await().text.any { it in '\u3040'..'\u30ff' }) return "ja"
        if (ko.process(img).await().text.any { it in '\uac00'..'\ud7a3' }) return "ko"
        if (zh.process(img).await().text.any { it in '\u4e00'..'\u9fff' }) return "zh"
        return "en"
    }

    /** تحسين الصورة قبل التعرف على النص: رمادي وتباين أعلى، وقلب الألوان إن كانت الخلفية داكنة. */
    private fun prepForOcr(src: Bitmap): Bitmap {
        var sum = 0L; var n = 0
        var y = 0
        while (y < src.height) {
            var x = 0
            while (x < src.width) { val c = src.getPixel(x, y); sum += (Color.red(c) + Color.green(c) + Color.blue(c)) / 3; n++; x += 16 }
            y += 16
        }
        val dark = n > 0 && sum / n < 110
        val cm = ColorMatrix()
        cm.setSaturation(0f)
        val c = 1.6f; val t = 128f * (1 - c)
        cm.postConcat(ColorMatrix(floatArrayOf(c, 0f, 0f, 0f, t, 0f, c, 0f, 0f, t, 0f, 0f, c, 0f, t, 0f, 0f, 0f, 1f, 0f)))
        if (dark) cm.postConcat(ColorMatrix(floatArrayOf(-1f, 0f, 0f, 0f, 255f, 0f, -1f, 0f, 0f, 255f, 0f, 0f, -1f, 0f, 255f, 0f, 0f, 0f, 1f, 0f)))
        val out = Bitmap.createBitmap(src.width, src.height, Bitmap.Config.ARGB_8888)
        Canvas(out).drawBitmap(src, 0f, 0f, Paint().apply { colorFilter = ColorMatrixColorFilter(cm) })
        return out
    }

    private fun fixCaps(t: String): String {
        if (t.any { it.isLowerCase() } || t.none { it.isUpperCase() }) return t
        return Regex("(^|[.!?…]\\s+)(\\p{L})").replace(t.lowercase()) { it.groupValues[1] + it.groupValues[2].uppercase() }
            .replace(Regex("\\bi\\b"), "I")
    }

    /** يقرأ النص من الصورة ويترجمه، ويعيد قناع التمويه وعناصر الترجمة مع النص الأصلي. */
    private suspend fun analyze(bmp: Bitmap): Analysis? {
        val p = Prefs.p(this)
        val tgt = p.getString("tgt", "ar")!!
        val isAuto = p.getString("src", "auto") == "auto"
        val src = if (isAuto) (detected ?: detect(bmp).also { detected = it }) else p.getString("src", "en")!!
        if (src == tgt) return null
        val res = recognizer(src).process(InputImage.fromBitmap(prepForOcr(bmp), 0)).await()
        // مستطيل الفقاعة الفعلي (وليس النافذة الثابتة العرض) حتى لا يُستبعد نص مجاور عن الترجمة
        val (cw, ch) = barSize()
        val capLeft = if (edge == 1) barLp.x + barLp.width - cw else barLp.x
        val barRect = Rect(capLeft, barLp.y, capLeft + cw, barLp.y + ch)
        val noSpace = src == "ja" || src == "zh"
        val latinLang = src != "ja" && src != "ko" && src != "zh"
        val blocks = res.textBlocks.mapNotNull { b ->
            val box = b.boundingBox ?: return@mapNotNull null
            if (Rect.intersects(box, barRect)) return@mapNotNull null
            var t = b.lines.joinToString(if (noSpace) "" else " ") { it.text }.trim()
            if (latinLang) t = fixCaps(t)
            if (t.length < 2 || t.none { it.isLetter() }) return@mapNotNull null
            Triple(b, box, t)
        }
        if (blocks.isEmpty()) { if (isAuto) detected = null; return null }
        val texts0 = blocks.map { it.third }
        val pre = texts0.map { Glossary.lookup(it, src, tgt) }
        val rest = translateAll(texts0.filterIndexed { i, _ -> pre[i] == null }, src, tgt, p)
        var ri = 0
        val outs: List<String?> = pre.map { it ?: rest[ri++] }
        val dict = if (tgt == "ar") Dict.load(this) else emptyMap()
        val scale = floatArrayOf(0.8f, 1f, 1.3f, 1.6f)[p.getInt("size", 1).coerceIn(0, 3)]
        val fixed = p.getInt("color", 0)

        val arr = IntArray(w * h)          // شفاف افتراضياً، ويُملأ فقط فوق النص الأصلي
        val items = ArrayList<Item>()
        val origs = ArrayList<String>()
        blocks.forEachIndexed { i, (b, box, orig) ->
            val tr = outs[i] ?: return@forEachIndexed
            val lines = b.lines.mapNotNull { it.boundingBox }.ifEmpty { listOf(box) }
            val lh = lines.map { it.height() }.average().toFloat()
            val pad = (lh * 0.45f).coerceIn(5f, 18f).toInt()
            // لون الفقاعة من حول الكتلة كاملة، ثم تغطية مصمتة إن كانت الخلفية منتظمة
            val ringRect = Rect(box.left - 6, box.top - 6, box.right + 6, box.bottom + 6)
            val ring = bgColor(bmp, ringRect)
            val fillC = medianColor(bmp, ringRect)
            val big = (lh * 0.7f).coerceIn(10f, 32f).toInt()
            maskInk(bmp, arr, Rect(box.left - big, box.top - big, box.right + big, box.bottom + big), fillC)
            val fg = if (fixed != 0) fixed else inkColor(bmp, lines, ring)
            origs.add(orig)
            items.add(Item(RectF(box), Dict.fix(tr, dict), fg, scale, ring, lh))
        }
        if (items.isEmpty()) return null
        return Analysis(Bitmap.createBitmap(arr, w, h, Bitmap.Config.ARGB_8888), items, origs)
    }

    /** ينتظر لقطة بالأبعاد الحالية (بعد التدوير قد تصل لقطات قديمة أو لا تصل لحظياً). */
    private suspend fun grabFresh(): Bitmap? {
        repeat(20) {
            val b = grab()
            if (b != null && b.width == w && b.height == h) return b
            delay(100)
        }
        return null
    }

    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private suspend fun translateAll(texts: List<String>, src: String, tgt: String, p: SharedPreferences): List<String?> {
        val key = "$src>$tgt>"
        if (cache.size > 400) cache.clear()
        val out = arrayOfNulls<String>(texts.size)
        val todo = ArrayList<Int>()
        texts.forEachIndexed { i, t -> val c = cache[key + t]; if (c != null) out[i] = c else todo.add(i) }
        if (todo.isNotEmpty()) {
            val q = todo.map { texts[it] }
            val k = p.getString("apikey", "")!!.trim()
            val eng = p.getInt("engine", 2)                       // 0 جهاز، 1 إنترنت، 2 تلقائي
            val useCloud = k.isNotEmpty() && (eng == 1 || (eng == 2 && online()))
            val cloudRes = if (useCloud) withContext(Dispatchers.IO) { cloud(q, src, tgt, k) } else null
            val res: List<String?> = cloudRes ?: run {             // احتياطي: الترجمة على الجهاز
                val tr = translator(src, tgt)
                coroutineScope {
                    q.map { t -> async { try { tr.translate(t).await() } catch (e: Exception) { null } } }.awaitAll()
                }
            }
            todo.forEachIndexed { j, i -> val r = res[j]; if (r != null) { out[i] = r; cache[key + texts[i]] = r } }
        }
        return out.toList()
    }

    private fun cloud(texts: List<String>, src: String, tgt: String, key: String): List<String>? = try {
        val body = texts.joinToString("&") { "q=" + URLEncoder.encode(it, "UTF-8") } +
            "&target=$tgt&source=$src&format=text"
        val con = URL("https://translation.googleapis.com/language/translate/v2?key=" + URLEncoder.encode(key, "UTF-8"))
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 8000; con.readTimeout = 15000
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        con.outputStream.use { it.write(body.toByteArray()) }
        if (con.responseCode != 200) null else {
            val arr = JSONObject(con.inputStream.bufferedReader().readText())
                .getJSONObject("data").getJSONArray("translations")
            List(arr.length()) { arr.getJSONObject(it).getString("translatedText") }
        }
    } catch (e: Exception) { null }

    private suspend fun translator(src: String, tgt: String): Translator {
        val t = translators.getOrPut("$src>$tgt") {
            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        }
        t.downloadModelIfNeeded().await()
        return t
    }

    // ---------------- التمويه ----------------
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())

    private fun fillRect(dst: IntArray, r: Rect, color: Int) {
        val x0 = r.left.coerceIn(0, w - 1); val x1 = r.right.coerceIn(0, w - 1)
        val y0 = r.top.coerceIn(0, h - 1); val y1 = r.bottom.coerceIn(0, h - 1)
        for (y in y0..y1) for (x in x0..x1) dst[y * w + x] = color
    }

    /** يلوّن بكسلات الحروف فقط (التي تختلف عن لون الفقاعة) داخل المنطقة، فتبقى حدود الفقاعة سليمة. */
    private fun maskInk(src: Bitmap, dst: IntArray, r: Rect, ring: Int) {
        val x0 = r.left.coerceIn(0, w - 1); val x1 = r.right.coerceIn(0, w - 1)
        val y0 = r.top.coerceIn(0, h - 1); val y1 = r.bottom.coerceIn(0, h - 1)
        if (x1 < x0 || y1 < y0) return
        val row = IntArray(x1 - x0 + 1)
        for (y in y0..y1) {
            src.getPixels(row, 0, row.size, x0, y, row.size, 1)
            for (i in row.indices) if (dist(row[i], ring) > 14) dst[y * w + x0 + i] = ring
        }
    }

    /** يتحقق من أن حواف المنطقة لها لون واحد تقريباً، أي أن الفقاعة منتظمة اللون. */
    private fun ringUniform(b: Bitmap, r: Rect, ref: Int): Boolean {
        val l = r.left.coerceIn(0, b.width - 1); val rr = r.right.coerceIn(0, b.width - 1)
        val t = r.top.coerceIn(0, b.height - 1); val bt = r.bottom.coerceIn(0, b.height - 1)
        var n = 0; var bad = 0
        var x = l
        while (x <= rr) {
            if (dist(b.getPixel(x, t), ref) > 90) bad++
            if (dist(b.getPixel(x, bt), ref) > 90) bad++
            n += 2; x += 4
        }
        var y = t
        while (y <= bt) {
            if (dist(b.getPixel(l, y), ref) > 90) bad++
            if (dist(b.getPixel(rr, y), ref) > 90) bad++
            n += 2; y += 4
        }
        return n > 0 && bad * 5 < n
    }

    /** للخلفيات المتدرجة (الرسوم): يملأ كل سطر بتدرج من حوافه. */
    private fun inpaint(src: Bitmap, dst: IntArray, r: Rect) {
        val W = src.width; val H = src.height
        val x0 = r.left.coerceIn(1, W - 2); val x1 = r.right.coerceIn(1, W - 2)
        val y0 = r.top.coerceIn(1, H - 2); val y1 = r.bottom.coerceIn(1, H - 2)
        if (x1 <= x0 || y1 <= y0) return
        val top = IntArray(x1 - x0 + 1) { src.getPixel(x0 + it, y0 - 1) }
        val bot = IntArray(x1 - x0 + 1) { src.getPixel(x0 + it, y1 + 1) }
        val fw = (x1 - x0).toFloat(); val fh = (y1 - y0).toFloat()
        for (y in y0..y1) {
            val lc = src.getPixel(x0 - 1, y); val rc = src.getPixel(x1 + 1, y)
            val s = (y - y0) / fh
            for (x in x0..x1) {
                val t = (x - x0) / fw
                dst[y * W + x] = mix(mix(lc, rc, t), mix(top[x - x0], bot[x - x0], s), 0.5f)
            }
        }
    }

    // ---------------- الألوان ----------------
    private fun dist(a: Int, b: Int) =
        abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))

    private fun contrast(bg: Int) =
        if ((Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 > 140) Color.BLACK else Color.WHITE

    private fun mode(px: List<Int>): Int {
        if (px.isEmpty()) return Color.WHITE
        val m = HashMap<Int, IntArray>()
        for (c in px) {
            val k = (Color.red(c) shr 4 shl 8) or (Color.green(c) shr 4 shl 4) or (Color.blue(c) shr 4)
            val a = m.getOrPut(k) { IntArray(4) }
            a[0]++; a[1] += Color.red(c); a[2] += Color.green(c); a[3] += Color.blue(c)
        }
        val best = m.values.maxByOrNull { it[0] }!!
        return Color.rgb(best[1] / best[0], best[2] / best[0], best[3] / best[0])
    }

    /** لون الخلفية حول النص بالوسيط لكل قناة، أثبت من المنوال مع الخلفيات المتدرجة. */
    private fun medianColor(b: Bitmap, r: Rect): Int {
        val l = (r.left - 3).coerceIn(0, b.width - 1)
        val rr = (r.right + 3).coerceIn(0, b.width - 1)
        val t = (r.top - 3).coerceIn(0, b.height - 1)
        val bt = (r.bottom + 3).coerceIn(0, b.height - 1)
        val rs = ArrayList<Int>(); val gs = ArrayList<Int>(); val bs = ArrayList<Int>()
        var x = l
        while (x <= rr) {
            for (y in intArrayOf(t, bt)) { val c = b.getPixel(x, y); rs.add(Color.red(c)); gs.add(Color.green(c)); bs.add(Color.blue(c)) }
            x += 3
        }
        var y = t
        while (y <= bt) {
            for (xx in intArrayOf(l, rr)) { val c = b.getPixel(xx, y); rs.add(Color.red(c)); gs.add(Color.green(c)); bs.add(Color.blue(c)) }
            y += 3
        }
        if (rs.isEmpty()) return Color.WHITE
        rs.sort(); gs.sort(); bs.sort()
        val m = rs.size / 2
        return Color.rgb(rs[m], gs[m], bs[m])
    }

    private fun bgColor(b: Bitmap, r: Rect): Int {
        val l = (r.left - 3).coerceIn(0, b.width - 1)
        val rr = (r.right + 3).coerceIn(0, b.width - 1)
        val t = (r.top - 3).coerceIn(0, b.height - 1)
        val bt = (r.bottom + 3).coerceIn(0, b.height - 1)
        val px = ArrayList<Int>()
        var x = l
        while (x <= rr) { px.add(b.getPixel(x, t)); px.add(b.getPixel(x, bt)); x += 4 }
        var y = t
        while (y <= bt) { px.add(b.getPixel(l, y)); px.add(b.getPixel(rr, y)); y += 4 }
        return mode(px)
    }

    private fun inkColor(b: Bitmap, lines: List<Rect>, bg: Int): Int {
        var n = 0; var r = 0L; var g = 0L; var bl = 0L
        for (ln in lines) {
            var y = ln.top.coerceAtLeast(0)
            while (y < ln.bottom.coerceAtMost(b.height)) {
                var x = ln.left.coerceAtLeast(0)
                while (x < ln.right.coerceAtMost(b.width)) {
                    val c = b.getPixel(x, y)
                    if (dist(c, bg) > 360) { n++; r += Color.red(c); g += Color.green(c); bl += Color.blue(c) }
                    x += 2
                }
                y += 2
            }
        }
        if (n < 6) return contrast(bg)
        val ink = Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
        return if (dist(ink, bg) < 250) contrast(bg) else ink
    }

    // ---------------- التقاط الشاشة ----------------
    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val p = img.planes[0]
            val rw = p.rowStride / p.pixelStride
            val b = Bitmap.createBitmap(rw, h, Bitmap.Config.ARGB_8888)
            b.copyPixelsFromBuffer(p.buffer)
            img.close()
            cached = if (rw == w) b else Bitmap.createBitmap(b, 0, 0, w, h)
        }
        return cached
    }

    private fun sig(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 24, 40, true)
        val a = IntArray(960)
        s.getPixels(a, 0, 24, 0, 0, 24, 40)
        return IntArray(960) { val c = a[it]; (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
    }

    private fun diff(a: IntArray, b: IntArray): Int {
        var d = 0L
        for (i in a.indices) d += abs(a[i] - b[i])
        return (d / a.size).toInt()
    }

    override fun onDestroy() {
        auto?.cancel(); scope.cancel()
        Prefs.p(this).edit().putBoolean("running", false).apply()
        try { wm.removeView(bar); wm.removeView(overlay); wm.removeView(watcher) } catch (_: Exception) {}
        vd?.release(); reader?.close(); proj?.stop()
        translators.values.forEach { it.close() }
        super.onDestroy()
    }
}
