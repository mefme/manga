package com.example.mangatrans

import android.app.*
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import kotlin.math.abs

@Suppress("DEPRECATION")
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private lateinit var overlay: TranslationOverlayView
    private lateinit var bar: LinearLayout
    private lateinit var barLp: LP
    private lateinit var autoBtn: TextView
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var auto: Job? = null
    @Volatile private var busy = false
    private var w = 0
    private var h = 0
    private var cached: Bitmap? = null

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val ja by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val translators = HashMap<String, Translator>()

    override fun onBind(i: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
    }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (proj != null || i == null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("c", "MangaTrans", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "c").setContentTitle("مترجم المانهوا يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data: Intent = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)!!
        else i.getParcelableExtra("data")!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        buildUi()
        return START_NOT_STICKY
    }

    private fun buildUi() {
        val t = LP.TYPE_APPLICATION_OVERLAY
        overlay = TranslationOverlayView(this)
        wm.addView(overlay, LP(w, h, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        fun btn(s: String) = TextView(this).apply {
            text = s; setTextColor(Color.WHITE); textSize = 15f; setPadding(28, 20, 28, 20)
        }
        val drag = btn("✥"); val one = btn("ترجمة"); autoBtn = btn("▶ مستمر"); val closeBtn = btn("✕")
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            background = GradientDrawable().apply { setColor(0xE6222222.toInt()); cornerRadius = 60f }
            addView(drag); addView(one); addView(autoBtn); addView(closeBtn)
        }
        barLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, t, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        wm.addView(bar, barLp)

        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0
        drag.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = barLp.x; oy = barLp.y }
                MotionEvent.ACTION_MOVE -> {
                    barLp.x = ox + (e.rawX - sx).toInt(); barLp.y = oy + (e.rawY - sy).toInt()
                    wm.updateViewLayout(bar, barLp)
                }
            }
            true
        }
        // ترجمة مرة واحدة (والضغط مرة ثانية يخفي الترجمة لرؤية الأصل)
        one.setOnClickListener {
            if (overlay.hasItems()) overlay.setItems(emptyList()) else scope.launch { pass() }
        }
        autoBtn.setOnClickListener { toggleAuto() }
        closeBtn.setOnClickListener { stopSelf() }
    }

    private fun toggleAuto() {
        if (auto != null) { auto?.cancel(); auto = null; autoBtn.text = "▶ مستمر"; return }
        autoBtn.text = "⏸ مستمر"
        auto = scope.launch {
            var prev: IntArray? = null
            var done: IntArray? = null
            while (isActive) {
                delay(350)
                if (busy) continue
                val s = sig(grab() ?: continue)
                val moving = prev == null || diff(prev, s) > 3   // الشاشة لا تزال تتحرك؟
                prev = s
                if (done != null && diff(done, s) <= 4) continue  // لا تغيير منذ آخر ترجمة
                if (overlay.hasItems()) main.post { overlay.setItems(emptyList()) }
                if (moving) continue                              // انتظر حتى تستقر الشاشة
                pass()
                delay(250)
                done = grab()?.let { sig(it) }
            }
        }
    }

    private suspend fun pass() {
        if (busy) return
        busy = true
        try {
            val had = withContext(Dispatchers.Main) { val x = overlay.hasItems(); overlay.setItems(emptyList()); x }
            if (had) delay(200)
            val bmp = grab() ?: return
            val src = getSharedPreferences("p", 0).getString("src", "en")!!
            val rec = when (src) { "ja" -> ja; "ko" -> ko; else -> latin }
            val res = rec.process(InputImage.fromBitmap(bmp, 0)).await()
            val barRect = Rect(barLp.x, barLp.y, barLp.x + bar.width, barLp.y + bar.height)
            val blocks = res.textBlocks.mapNotNull { b ->
                val r = b.boundingBox ?: return@mapNotNull null
                if (Rect.intersects(r, barRect)) return@mapNotNull null
                val t = b.lines.joinToString(if (src == "ja") "" else " ") { it.text }.trim()
                if (t.length < 2 || t.none { it.isLetter() }) null else r to t
            }
            val tr = translator(src)
            val dict = Dict.load(this)
            val out = coroutineScope {
                blocks.map { (r, t) ->
                    async {
                        val a = try { tr.translate(t).await() } catch (e: Exception) { null }
                        a?.let { RectF(r) to Dict.fix(it, dict) }
                    }
                }.awaitAll().filterNotNull()
            }
            withContext(Dispatchers.Main) { overlay.setItems(out) }
        } finally { busy = false }
    }

    private suspend fun translator(src: String): Translator {
        val code = when (src) { "ja" -> TranslateLanguage.JAPANESE; "ko" -> TranslateLanguage.KOREAN; else -> TranslateLanguage.ENGLISH }
        val t = translators.getOrPut(src) {
            Translation.getClient(TranslatorOptions.Builder()
                .setSourceLanguage(code).setTargetLanguage(TranslateLanguage.ARABIC).build())
        }
        t.downloadModelIfNeeded().await()
        return t
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val p = img.planes[0]
            val rw = p.rowStride / p.pixelStride
            val b = Bitmap.createBitmap(rw, h, Bitmap.Config.ARGB_8888)
            b.copyPixelsFromBuffer(p.buffer)
            img.close()
            cached = if (rw == w) b else Bitmap.createBitmap(b, 0, 0, w, h)
        }
        return cached
    }

    private fun sig(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 24, 40, true)
        val a = IntArray(960)
        s.getPixels(a, 0, 24, 0, 0, 24, 40)
        return IntArray(960) { val c = a[it]; (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
    }

    private fun diff(a: IntArray, b: IntArray): Int {
        var d = 0L
        for (i in a.indices) d += abs(a[i] - b[i])
        return (d / a.size).toInt()
    }

    override fun onDestroy() {
        auto?.cancel(); scope.cancel()
        try { wm.removeView(bar); wm.removeView(overlay) } catch (_: Exception) {}
        vd?.release(); reader?.close(); proj?.stop()
        translators.values.forEach { it.close() }
        super.onDestroy()
    }
}
