package com.example.mangatrans

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.util.DisplayMetrics
import android.util.TypedValue
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.*
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

@Suppress("DEPRECATION")
class OverlayService : Service() {
    companion object { const val ACTION_STOP = "com.example.mangatrans.STOP" }

    private class Analysis(val patch: Bitmap, val items: List<Item>, val origs: List<String>)

    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private lateinit var overlay: TranslationOverlayView
    private lateinit var watcher: View
    private lateinit var bar: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var handle: ImageView
    private lateinit var dot: View
    private lateinit var barLp: LP
    private lateinit var snapBtn: ImageView
    private lateinit var autoBtn: ImageView
    private var snapView: View? = null
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var auto: Job? = null
    @Volatile private var busy = false
    @Volatile private var gen = 0            // يزداد عند كل لمسة على الشاشة
    @Volatile private var collapsed = false   // الفقاعة منطوية على الحافة
    private var collapseLeft = true
    private var w = 0
    private var h = 0
    private var cached: Bitmap? = null
    private var detected: String? = null
    private val cache = HashMap<String, String>()

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val ja by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val zh by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val langId by lazy { LanguageIdentification.getClient() }
    private val translators = HashMap<String, Translator>()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (proj != null || i == null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("c", "MangaTrans", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "c")
            .setContentTitle("مترجم المانهوا يعمل")
            .setContentText("الفقاعة تعمل فوق التطبيقات")
            .setSmallIcon(R.drawable.ic_translate)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data: Intent = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)!!
        else i.getParcelableExtra("data")!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        Prefs.p(this).edit().putBoolean("running", true).apply()
        buildUi()
        return START_NOT_STICKY
    }

    // ---------------- الواجهة العائمة ----------------
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun circle(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun ripple(bg: Int) = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), circle(bg), null)
    private fun icon(res: Int, bg: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(Color.WHITE)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = ripple(bg)
        layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(4) }
        isClickable = true
    }
    private fun tap(v: View) = v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)

    private fun buildUi() {
        val t = LP.TYPE_APPLICATION_OVERLAY
        overlay = TranslationOverlayView(this)
        wm.addView(overlay, LP(w, h, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        // مستشعر اللمس: نافذة صغيرة ترى اللمسات الخارجية دون أن تمنعها عن التطبيق
        watcher = object : View(this@OverlayService) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_OUTSIDE && auto != null) onScreenTouched()
                return false
            }
        }
        wm.addView(watcher, LP(1, 1, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_WATCH_OUTSIDE_TOUCH or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        handle = ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = circle(Ui.ACCENT)
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }
        dot = View(this).apply {
            background = circle(0xFF8E8E93.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginStart = dp(6); marginEnd = dp(4) }
        }
        snapBtn = icon(R.drawable.ic_eye, 0x33FFFFFF)     // لقطة شاشة مترجمة قابلة للنسخ
        autoBtn = icon(R.drawable.ic_play, 0x33FFFFFF)    // ترجمة مستمرة
        val closeBtn = icon(R.drawable.ic_close, 0x33FF3B30)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(snapBtn); addView(autoBtn); addView(closeBtn)
        }
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(0xEB17181F.toInt(), dp(40).toFloat())
            setPadding(dp(5), dp(5), dp(6), dp(5))
            addView(handle); addView(dot); addView(panel)
        }
        barLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(6); y = h / 3 }
        wm.addView(bar, barLp)

        // السحب يحرك الكبسولة، والضغطة القصيرة تطويها أو تفتحها، وعند الإفلات تلتصق بالحافة
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = barLp.x; oy = barLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) { barLp.x = ox + dx.toInt(); barLp.y = oy + dy.toInt(); wm.updateViewLayout(bar, barLp) }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        tap(handle)
                        if (collapsed) expandFromEdge()
                        else if (auto != null) collapseToEdge()
                        else {
                            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            wm.updateViewLayout(bar, barLp)
                        }
                    } else {
                        if (collapsed) expandFromEdge()
                        snapToEdge()
                    }
                }
            }
            true
        }
        snapBtn.setOnClickListener { tap(it); openSnapshot() }
        autoBtn.setOnClickListener { tap(it); toggleAuto() }
        closeBtn.setOnClickListener { stopSelf() }
        refreshStatus()
    }

    private fun barWidth(): Int {
        bar.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        return bar.measuredWidth
    }

    private fun snapToEdge() {
        val bw = barWidth(); val bh = bar.measuredHeight
        barLp.x = if (barLp.x + bw / 2 < w / 2) dp(6) else w - bw - dp(6)
        barLp.y = barLp.y.coerceIn(dp(40), (h - bh - dp(40)).coerceAtLeast(dp(40)))
        wm.updateViewLayout(bar, barLp)
    }

    /** طيّ الفقاعة إلى سهم صغير على حافة الشاشة (يُستخدم أثناء الترجمة المستمرة فقط). */
    private fun collapseToEdge() {
        if (collapsed) return
        collapseLeft = barLp.x + barWidth() / 2 < w / 2
        panel.visibility = View.GONE; dot.visibility = View.GONE
        barLp.x = if (collapseLeft) -dp(16) else w - dp(40)
        handle.setImageResource(R.drawable.ic_chevron)
        handle.rotation = if (collapseLeft) 0f else 180f
        collapsed = true
        wm.updateViewLayout(bar, barLp)
    }

    /** إخراج الفقاعة من الحافة إلى وضعها الكامل. */
    private fun expandFromEdge() {
        collapsed = false
        handle.setImageResource(R.drawable.ic_translate); handle.rotation = 0f
        dot.visibility = View.VISIBLE; panel.visibility = View.VISIBLE
        snapToEdge()
    }

    private fun refreshStatus() {
        main.post {
            val running = auto != null
            dot.background = circle(when {
                busy -> 0xFFFFC107.toInt()
                running -> 0xFF2EB67D.toInt()
                else -> 0xFF8E8E93.toInt()
            })
            autoBtn.setImageResource(if (running) R.drawable.ic_pause else R.drawable.ic_play)
            autoBtn.background = ripple(if (running) 0xFF2EB67D.toInt() else 0x33FFFFFF)
        }
    }

    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    // ---------------- لقطة الشاشة المترجمة (قابلة للنسخ) ----------------
    private fun openSnapshot() {
        if (snapView != null) return
        scope.launch {
            if (busy) return@launch
            busy = true; refreshStatus()
            try {
                val src = grab() ?: return@launch
                val orig = src.copy(Bitmap.Config.ARGB_8888, false)
                val a = analyze(orig)
                if (a == null) { toast("لم أجد نصاً على الشاشة"); return@launch }
                val comp = orig.copy(Bitmap.Config.ARGB_8888, true)
                Canvas(comp).drawBitmap(a.patch, 0f, 0f, null)
                main.post { showSnapshot(orig, comp, a) }
            } finally {
                busy = false; refreshStatus()
            }
        }
    }

    private fun pill(label: String, on: Boolean) = TextView(this).apply {
        text = label; textSize = 14f; typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER
        setTextColor(if (on) Color.WHITE else 0xFF1B1D2A.toInt())
        background = Ui.round(if (on) Ui.ACCENT else 0xFFFFFFFF.toInt(), dp(20).toFloat())
        setPadding(dp(14), dp(8), dp(14), dp(8))
        layoutParams = LinearLayout.LayoutParams(-2, -2).apply { marginEnd = dp(8) }
    }

    private fun showSnapshot(orig: Bitmap, comp: Bitmap, a: Analysis) {
        val root = FrameLayout(this).apply { setBackgroundColor(Color.BLACK) }
        val img = ImageView(this).apply {
            setImageBitmap(comp); scaleType = ImageView.ScaleType.FIT_XY
            layoutParams = FrameLayout.LayoutParams(w, h)
        }
        root.addView(img)

        // طبقة الترجمة وطبقة النص الأصلي: كلاهما نصوص حقيقية قابلة للتحديد والنسخ
        val trGroup = FrameLayout(this)
        val orGroup = FrameLayout(this).apply { visibility = View.GONE }
        a.items.forEachIndexed { i, item ->
            trGroup.addView(textAt(item.box, item.text, item.fg, true, item.lineH))
            orGroup.addView(textAt(item.box, a.origs[i], item.fg, false, item.lineH))
        }
        root.addView(trGroup); root.addView(orGroup)

        var showingTr = true
        val trBtn = pill("الترجمة", true)
        val orBtn = pill("الأصل", false)
        val copyBtn = pill("نسخ الكل", false)
        val closeBtn = pill("✕", false)
        fun mode(tr: Boolean) {
            showingTr = tr
            img.setImageBitmap(if (tr) comp else orig)
            trGroup.visibility = if (tr) View.VISIBLE else View.GONE
            orGroup.visibility = if (tr) View.GONE else View.VISIBLE
            trBtn.background = Ui.round(if (tr) Ui.ACCENT else 0xFFFFFFFF.toInt(), dp(20).toFloat())
            trBtn.setTextColor(if (tr) Color.WHITE else 0xFF1B1D2A.toInt())
            orBtn.background = Ui.round(if (!tr) Ui.ACCENT else 0xFFFFFFFF.toInt(), dp(20).toFloat())
            orBtn.setTextColor(if (!tr) Color.WHITE else 0xFF1B1D2A.toInt())
        }
        trBtn.setOnClickListener { tap(it); mode(true) }
        orBtn.setOnClickListener { tap(it); mode(false) }
        copyBtn.setOnClickListener {
            tap(it)
            val text = if (showingTr) a.items.joinToString("\n") { x -> x.text } else a.origs.joinToString("\n")
            getSystemService(android.content.ClipboardManager::class.java)
                .setPrimaryClip(android.content.ClipData.newPlainText("نص", text))
            toast("تم النسخ")
        }
        closeBtn.setOnClickListener { tap(it); hideSnapshot() }

        val barRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            background = Ui.round(0xE617181F.toInt(), dp(30).toFloat())
            setPadding(dp(8), dp(8), dp(8), dp(8))
            addView(trBtn); addView(orBtn); addView(copyBtn); addView(closeBtn)
        }
        root.addView(barRow, FrameLayout.LayoutParams(-2, -2, Gravity.TOP or Gravity.CENTER_HORIZONTAL).apply {
            topMargin = dp(36)
        })

        snapView = root
        // نافذة قابلة للتركيز لتعمل ميزة التحديد والنسخ، وتغطي الشاشة كلها
        wm.addView(root, LP(w, h, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS, PixelFormat.TRANSLUCENT))
    }

    private fun hideSnapshot() {
        snapView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        snapView = null
    }

    private fun textAt(box: RectF, text: String, color: Int, rtl: Boolean, lineH: Float): TextView {
        val bw = box.width().toInt() + dp(12)
        val bh = box.height().toInt() + dp(8)
        return TextView(this).apply {
            this.text = text
            setTextColor(color); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
            textDirection = if (rtl) View.TEXT_DIRECTION_RTL else View.TEXT_DIRECTION_LTR
            setTextIsSelectable(true)
            setAutoSizeTextTypeUniformWithConfiguration(8, lineH.toInt().coerceAtLeast(12), 1, TypedValue.COMPLEX_UNIT_PX)
            layoutParams = FrameLayout.LayoutParams(bw, bh).apply {
                leftMargin = box.left.toInt() - dp(6); topMargin = box.top.toInt() - dp(4)
            }
        }
    }

    /** لمسة على الشاشة أثناء الترجمة المستمرة: إخفاء فوري ثم إعادة الترجمة عند توقف الحركة. */
    private fun onScreenTouched() {
        gen++
        main.post { overlay.clear() }
    }

    private fun toggleAuto() {
        if (auto != null) {
            auto?.cancel(); auto = null
            if (collapsed) expandFromEdge()
            refreshStatus()
            return
        }
        collapseToEdge()
        auto = scope.launch {
            var prev: IntArray? = null
            var done: IntArray? = null
            var seen = gen
            while (isActive) {
                delay(300)
                if (gen != seen) { seen = gen; prev = null; done = null; continue }
                if (busy) continue
                val s = sig(grab() ?: continue)
                val moving = prev == null || diff(prev!!, s) > 3
                prev = s
                if (done != null && diff(done!!, s) <= 4) continue
                if (overlay.hasItems()) main.post { overlay.clear() }
                if (moving) continue
                pass()
                delay(200)
                done = grab()?.let { sig(it) }
            }
        }
        refreshStatus()
    }

    private suspend fun pass() {
        if (busy) return
        busy = true
        val myGen = gen
        refreshStatus()
        try {
            withContext(Dispatchers.Main) { overlay.clear() }
            val bmp = grab() ?: return
            val a = analyze(bmp) ?: return
            if (gen != myGen) return           // المستخدم لمس الشاشة أثناء المعالجة، فنتجاهل النتيجة
            withContext(Dispatchers.Main) {
                overlay.show(a.patch, a.items)
            }
        } finally {
            busy = false
            refreshStatus()
        }
    }

    // ---------------- خط المعالجة ----------------
    private fun recognizer(src: String) = when (src) { "ja" -> ja; "ko" -> ko; "zh" -> zh; else -> latin }

    private suspend fun detect(bmp: Bitmap): String {
        val img = InputImage.fromBitmap(bmp, 0)
        val lt = latin.process(img).await().text
        if (lt.count { it in 'A'..'Z' || it in 'a'..'z' || it in 'À'..'ÿ' } >= 10) {
            val code = try { langId.identifyLanguage(lt.replace('\n', ' ')).await() } catch (e: Exception) { "und" }
            return if (code in setOf("en", "fr", "es", "de", "it", "pt")) code else "en"
        }
        if (ja.process(img).await().text.any { it in '\u3040'..'\u30ff' }) return "ja"
        if (ko.process(img).await().text.any { it in '\uac00'..'\ud7a3' }) return "ko"
        if (zh.process(img).await().text.any { it in '\u4e00'..'\u9fff' }) return "zh"
        return "en"
    }

    private fun fixCaps(t: String): String {
        if (t.any { it.isLowerCase() } || t.none { it.isUpperCase() }) return t
        return Regex("(^|[.!?…]\\s+)(\\p{L})").replace(t.lowercase()) { it.groupValues[1] + it.groupValues[2].uppercase() }
            .replace(Regex("\\bi\\b"), "I")
    }

    /** يقرأ النص من الصورة ويترجمه، ويعيد قناع التمويه وعناصر الترجمة مع النص الأصلي. */
    private suspend fun analyze(bmp: Bitmap): Analysis? {
        val p = Prefs.p(this)
        val tgt = p.getString("tgt", "ar")!!
        val isAuto = p.getString("src", "auto") == "auto"
        val src = if (isAuto) (detected ?: detect(bmp).also { detected = it }) else p.getString("src", "en")!!
        if (src == tgt) return null
        val res = recognizer(src).process(InputImage.fromBitmap(bmp, 0)).await()
        val barRect = Rect(barLp.x, barLp.y, barLp.x + bar.width, barLp.y + bar.height)
        val noSpace = src == "ja" || src == "zh"
        val latinLang = src != "ja" && src != "ko" && src != "zh"
        val blocks = res.textBlocks.mapNotNull { b ->
            val box = b.boundingBox ?: return@mapNotNull null
            if (Rect.intersects(box, barRect)) return@mapNotNull null
            var t = b.lines.joinToString(if (noSpace) "" else " ") { it.text }.trim()
            if (latinLang) t = fixCaps(t)
            if (t.length < 2 || t.none { it.isLetter() }) return@mapNotNull null
            Triple(b, box, t)
        }
        if (blocks.isEmpty()) { if (isAuto) detected = null; return null }
        val outs = translateAll(blocks.map { it.third }, src, tgt, p)
        val dict = if (tgt == "ar") Dict.load(this) else emptyMap()
        val scale = floatArrayOf(0.8f, 1f, 1.3f)[p.getInt("size", 1).coerceIn(0, 2)]
        val fixed = p.getInt("color", 0)

        val arr = IntArray(w * h)          // شفاف افتراضياً، ويُملأ فقط فوق النص الأصلي
        val items = ArrayList<Item>()
        val origs = ArrayList<String>()
        blocks.forEachIndexed { i, (b, box, orig) ->
            val tr = outs[i] ?: return@forEachIndexed
            val lines = b.lines.mapNotNull { it.boundingBox }.ifEmpty { listOf(box) }
            val lh = lines.map { it.height() }.average().toFloat()
            val pad = (lh * 0.45f).coerceIn(5f, 18f).toInt()
            // لون الفقاعة من حول الكتلة كاملة، ثم تغطية مصمتة إن كانت الخلفية منتظمة
            val ringRect = Rect(box.left - 6, box.top - 6, box.right + 6, box.bottom + 6)
            val ring = bgColor(bmp, ringRect)
            if (ringUniform(bmp, ringRect, ring)) {
                val big = (lh * 0.6f).coerceIn(8f, 30f).toInt()
                fillRect(arr, Rect(box.left - big, box.top - big, box.right + big, box.bottom + big), ring)
            } else {
                lines.forEach { l -> inpaint(bmp, arr, Rect(l.left - pad, l.top - pad, l.right + pad, l.bottom + pad)) }
            }
            val fg = if (fixed != 0) fixed else inkColor(bmp, lines, ring)
            origs.add(orig)
            items.add(Item(RectF(box), Dict.fix(tr, dict), fg, scale, ring, lh))
        }
        if (items.isEmpty()) return null
        return Analysis(Bitmap.createBitmap(arr, w, h, Bitmap.Config.ARGB_8888), items, origs)
    }

    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private suspend fun translateAll(texts: List<String>, src: String, tgt: String, p: SharedPreferences): List<String?> {
        val key = "$src>$tgt>"
        if (cache.size > 400) cache.clear()
        val out = arrayOfNulls<String>(texts.size)
        val todo = ArrayList<Int>()
        texts.forEachIndexed { i, t -> val c = cache[key + t]; if (c != null) out[i] = c else todo.add(i) }
        if (todo.isNotEmpty()) {
            val q = todo.map { texts[it] }
            val k = p.getString("apikey", "")!!.trim()
            val eng = p.getInt("engine", 2)                       // 0 جهاز، 1 إنترنت، 2 تلقائي
            val useCloud = k.isNotEmpty() && (eng == 1 || (eng == 2 && online()))
            val cloudRes = if (useCloud) withContext(Dispatchers.IO) { cloud(q, src, tgt, k) } else null
            val res: List<String?> = cloudRes ?: run {             // احتياطي: الترجمة على الجهاز
                val tr = translator(src, tgt)
                coroutineScope {
                    q.map { t -> async { try { tr.translate(t).await() } catch (e: Exception) { null } } }.awaitAll()
                }
            }
            todo.forEachIndexed { j, i -> val r = res[j]; if (r != null) { out[i] = r; cache[key + texts[i]] = r } }
        }
        return out.toList()
    }

    private fun cloud(texts: List<String>, src: String, tgt: String, key: String): List<String>? = try {
        val body = texts.joinToString("&") { "q=" + URLEncoder.encode(it, "UTF-8") } +
            "&target=$tgt&source=$src&format=text"
        val con = URL("https://translation.googleapis.com/language/translate/v2?key=" + URLEncoder.encode(key, "UTF-8"))
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 8000; con.readTimeout = 15000
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        con.outputStream.use { it.write(body.toByteArray()) }
        if (con.responseCode != 200) null else {
            val arr = JSONObject(con.inputStream.bufferedReader().readText())
                .getJSONObject("data").getJSONArray("translations")
            List(arr.length()) { arr.getJSONObject(it).getString("translatedText") }
        }
    } catch (e: Exception) { null }

    private suspend fun translator(src: String, tgt: String): Translator {
        val t = translators.getOrPut("$src>$tgt") {
            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        }
        t.downloadModelIfNeeded().await()
        return t
    }

    // ---------------- التمويه ----------------
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())

    private fun fillRect(dst: IntArray, r: Rect, color: Int) {
        val x0 = r.left.coerceIn(0, w - 1); val x1 = r.right.coerceIn(0, w - 1)
        val y0 = r.top.coerceIn(0, h - 1); val y1 = r.bottom.coerceIn(0, h - 1)
        for (y in y0..y1) for (x in x0..x1) dst[y * w + x] = color
    }

    /** يتحقق من أن حواف المنطقة لها لون واحد تقريباً، أي أن الفقاعة منتظمة اللون. */
    private fun ringUniform(b: Bitmap, r: Rect, ref: Int): Boolean {
        val l = r.left.coerceIn(0, b.width - 1); val rr = r.right.coerceIn(0, b.width - 1)
        val t = r.top.coerceIn(0, b.height - 1); val bt = r.bottom.coerceIn(0, b.height - 1)
        var n = 0; var bad = 0
        var x = l
        while (x <= rr) {
            if (dist(b.getPixel(x, t), ref) > 90) bad++
            if (dist(b.getPixel(x, bt), ref) > 90) bad++
            n += 2; x += 4
        }
        var y = t
        while (y <= bt) {
            if (dist(b.getPixel(l, y), ref) > 90) bad++
            if (dist(b.getPixel(rr, y), ref) > 90) bad++
            n += 2; y += 4
        }
        return n > 0 && bad * 5 < n
    }

    /** للخلفيات المتدرجة (الرسوم): يملأ كل سطر بتدرج من حوافه. */
    private fun inpaint(src: Bitmap, dst: IntArray, r: Rect) {
        val W = src.width; val H = src.height
        val x0 = r.left.coerceIn(1, W - 2); val x1 = r.right.coerceIn(1, W - 2)
        val y0 = r.top.coerceIn(1, H - 2); val y1 = r.bottom.coerceIn(1, H - 2)
        if (x1 <= x0 || y1 <= y0) return
        val top = IntArray(x1 - x0 + 1) { src.getPixel(x0 + it, y0 - 1) }
        val bot = IntArray(x1 - x0 + 1) { src.getPixel(x0 + it, y1 + 1) }
        val fw = (x1 - x0).toFloat(); val fh = (y1 - y0).toFloat()
        for (y in y0..y1) {
            val lc = src.getPixel(x0 - 1, y); val rc = src.getPixel(x1 + 1, y)
            val s = (y - y0) / fh
            for (x in x0..x1) {
                val t = (x - x0) / fw
                dst[y * W + x] = mix(mix(lc, rc, t), mix(top[x - x0], bot[x - x0], s), 0.5f)
            }
        }
    }

    // ---------------- الألوان ----------------
    private fun dist(a: Int, b: Int) =
        abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))

    private fun contrast(bg: Int) =
        if ((Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 > 140) Color.BLACK else Color.WHITE

    private fun mode(px: List<Int>): Int {
        if (px.isEmpty()) return Color.WHITE
        val m = HashMap<Int, IntArray>()
        for (c in px) {
            val k = (Color.red(c) shr 4 shl 8) or (Color.green(c) shr 4 shl 4) or (Color.blue(c) shr 4)
            val a = m.getOrPut(k) { IntArray(4) }
            a[0]++; a[1] += Color.red(c); a[2] += Color.green(c); a[3] += Color.blue(c)
        }
        val best = m.values.maxByOrNull { it[0] }!!
        return Color.rgb(best[1] / best[0], best[2] / best[0], best[3] / best[0])
    }

    private fun bgColor(b: Bitmap, r: Rect): Int {
        val l = (r.left - 3).coerceIn(0, b.width - 1)
        val rr = (r.right + 3).coerceIn(0, b.width - 1)
        val t = (r.top - 3).coerceIn(0, b.height - 1)
        val bt = (r.bottom + 3).coerceIn(0, b.height - 1)
        val px = ArrayList<Int>()
        var x = l
        while (x <= rr) { px.add(b.getPixel(x, t)); px.add(b.getPixel(x, bt)); x += 4 }
        var y = t
        while (y <= bt) { px.add(b.getPixel(l, y)); px.add(b.getPixel(rr, y)); y += 4 }
        return mode(px)
    }

    private fun inkColor(b: Bitmap, lines: List<Rect>, bg: Int): Int {
        var n = 0; var r = 0L; var g = 0L; var bl = 0L
        for (ln in lines) {
            var y = ln.top.coerceAtLeast(0)
            while (y < ln.bottom.coerceAtMost(b.height)) {
                var x = ln.left.coerceAtLeast(0)
                while (x < ln.right.coerceAtMost(b.width)) {
                    val c = b.getPixel(x, y)
                    if (dist(c, bg) > 360) { n++; r += Color.red(c); g += Color.green(c); bl += Color.blue(c) }
                    x += 2
                }
                y += 2
            }
        }
        if (n < 6) return contrast(bg)
        val ink = Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
        return if (dist(ink, bg) < 250) contrast(bg) else ink
    }

    // ---------------- التقاط الشاشة ----------------
    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val p = img.planes[0]
            val rw = p.rowStride / p.pixelStride
            val b = Bitmap.createBitmap(rw, h, Bitmap.Config.ARGB_8888)
            b.copyPixelsFromBuffer(p.buffer)
            img.close()
            cached = if (rw == w) b else Bitmap.createBitmap(b, 0, 0, w, h)
        }
        return cached
    }

    private fun sig(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 24, 40, true)
        val a = IntArray(960)
        s.getPixels(a, 0, 24, 0, 0, 24, 40)
        return IntArray(960) { val c = a[it]; (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
    }

    private fun diff(a: IntArray, b: IntArray): Int {
        var d = 0L
        for (i in a.indices) d += abs(a[i] - b[i])
        return (d / a.size).toInt()
    }

    override fun onDestroy() {
        auto?.cancel(); scope.cancel()
        Prefs.p(this).edit().putBoolean("running", false).apply()
        try { wm.removeView(bar); wm.removeView(overlay); wm.removeView(watcher) } catch (_: Exception) {}
        hideSnapshot()
        vd?.release(); reader?.close(); proj?.stop()
        translators.values.forEach { it.close() }
        super.onDestroy()
    }
}
