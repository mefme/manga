package com.example.mangatrans

import android.app.*
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.content.res.ColorStateList
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.RippleDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.net.ConnectivityManager
import android.net.NetworkCapabilities
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.*
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

@Suppress("DEPRECATION")
class OverlayService : Service() {
    companion object { const val ACTION_STOP = "com.example.mangatrans.STOP" }

    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private lateinit var overlay: TranslationOverlayView
    private lateinit var watcher: View
    private lateinit var bar: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var handle: ImageView
    private lateinit var dot: View
    private lateinit var barLp: LP
    private lateinit var one: ImageView
    private lateinit var autoBtn: ImageView
    private lateinit var copyBtn: ImageView
    private lateinit var textBtn: ImageView
    private var textPanelView: View? = null
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var auto: Job? = null
    @Volatile private var busy = false
    @Volatile private var gen = 0          // يزداد عند كل لمسة على الشاشة
    @Volatile private var collapsed = false // الفقاعة منطوية على الحافة
    private var w = 0
    private var h = 0
    private var cached: Bitmap? = null
    private var detected: String? = null
    private var lastTrans = ""
    private var lastOrig = ""
    private val cache = HashMap<String, String>()

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val ja by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val zh by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val langId by lazy { LanguageIdentification.getClient() }
    private val translators = HashMap<String, Translator>()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (i?.action == ACTION_STOP) { stopSelf(); return START_NOT_STICKY }
        if (proj != null || i == null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("c", "MangaTrans", NotificationManager.IMPORTANCE_LOW))
        val stopPi = PendingIntent.getService(this, 0,
            Intent(this, OverlayService::class.java).setAction(ACTION_STOP), PendingIntent.FLAG_IMMUTABLE)
        val n = Notification.Builder(this, "c")
            .setContentTitle("مترجم المانهوا يعمل")
            .setContentText("الفقاعة تعمل فوق التطبيقات")
            .setSmallIcon(R.drawable.ic_translate)
            .setOngoing(true)
            .addAction(android.R.drawable.ic_menu_close_clear_cancel, "إيقاف", stopPi)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data: Intent = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)!!
        else i.getParcelableExtra("data")!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        Prefs.p(this).edit().putBoolean("running", true).apply()
        buildUi()
        return START_NOT_STICKY
    }

    // ---------------- الواجهة العائمة ----------------
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun circle(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun ripple(bg: Int) = RippleDrawable(ColorStateList.valueOf(0x40FFFFFF), circle(bg), null)
    private fun icon(res: Int, bg: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(Color.WHITE)
        setPadding(dp(10), dp(10), dp(10), dp(10))
        background = ripple(bg)
        layoutParams = LinearLayout.LayoutParams(dp(42), dp(42)).apply { marginStart = dp(4) }
        isClickable = true
    }
    private fun tap(v: View) = v.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)

    private fun buildUi() {
        val t = LP.TYPE_APPLICATION_OVERLAY
        overlay = TranslationOverlayView(this)
        wm.addView(overlay, LP(w, h, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        // مستشعر اللمس: نافذة صغيرة ترى اللمسات الخارجية دون أن تمنعها عن التطبيق
        watcher = object : View(this@OverlayService) {
            override fun onTouchEvent(e: MotionEvent): Boolean {
                if (e.action == MotionEvent.ACTION_OUTSIDE && auto != null) onScreenTouched()
                return false
            }
        }
        wm.addView(watcher, LP(1, 1, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_WATCH_OUTSIDE_TOUCH or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        handle = ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = circle(Ui.ACCENT)
            layoutParams = LinearLayout.LayoutParams(dp(46), dp(46))
        }
        dot = View(this).apply {
            background = circle(0xFF8E8E93.toInt())
            layoutParams = LinearLayout.LayoutParams(dp(8), dp(8)).apply { marginStart = dp(6); marginEnd = dp(4) }
        }
        one = icon(R.drawable.ic_eye, 0x33FFFFFF)
        autoBtn = icon(R.drawable.ic_play, 0x33FFFFFF)
        copyBtn = icon(R.drawable.ic_copy, 0x33FFFFFF)
        textBtn = icon(R.drawable.ic_text, 0x33FFFFFF)
        val closeBtn = icon(R.drawable.ic_close, 0x33FF3B30)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(one); addView(autoBtn); addView(copyBtn); addView(textBtn); addView(closeBtn)
        }
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(0xEB17181F.toInt(), dp(40).toFloat())
            setPadding(dp(5), dp(5), dp(6), dp(5))
            addView(handle); addView(dot); addView(panel)
        }
        barLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = dp(6); y = h / 3 }
        wm.addView(bar, barLp)

        // السحب يحرك الكبسولة، والضغطة القصيرة تطويها أو تفتحها، وعند الإفلات تلتصق بالحافة
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = barLp.x; oy = barLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) { barLp.x = ox + dx.toInt(); barLp.y = oy + dy.toInt(); wm.updateViewLayout(bar, barLp) }
                }
                MotionEvent.ACTION_UP -> {
                    if (!moved) {
                        tap(handle)
                        if (collapsed) expandFromEdge()
                        else {
                            panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                            wm.updateViewLayout(bar, barLp)
                        }
                    } else {
                        if (collapsed) expandFromEdge()
                        snapToEdge()
                    }
                }
            }
            true
        }
        one.setOnClickListener { tap(it); if (overlay.hasItems()) overlay.clear() else scope.launch { pass() } }
        autoBtn.setOnClickListener { tap(it); toggleAuto() }
        copyBtn.setOnClickListener { tap(it); copyTrans() }
        textBtn.setOnClickListener { tap(it); showTextPanel() }
        closeBtn.setOnClickListener { stopSelf() }
        refreshStatus()
    }

    private fun barWidth(): Int {
        bar.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED)
        return bar.measuredWidth
    }

    private fun snapToEdge() {
        val bw = barWidth(); val bh = bar.measuredHeight
        barLp.x = if (barLp.x + bw / 2 < w / 2) dp(6) else w - bw - dp(6)
        barLp.y = barLp.y.coerceIn(dp(40), (h - bh - dp(40)).coerceAtLeast(dp(40)))
        wm.updateViewLayout(bar, barLp)
    }

    /** طيّ الفقاعة إلى زر نصف مخفي على حافة الشاشة، كما في Google Translate. */
    private fun collapseToEdge() {
        if (collapsed) return
        val left = barLp.x + barWidth() / 2 < w / 2
        panel.visibility = View.GONE; dot.visibility = View.GONE
        val bw = barWidth()
        barLp.x = if (left) -(bw - dp(26)) else w - dp(26)
        collapsed = true
        wm.updateViewLayout(bar, barLp)
    }

    private fun expandFromEdge() {
        collapsed = false
        dot.visibility = View.VISIBLE; panel.visibility = View.VISIBLE
        snapToEdge()
    }

    private fun refreshStatus() {
        main.post {
            val running = auto != null
            dot.background = circle(when {
                busy -> 0xFFFFC107.toInt()
                running -> 0xFF2EB67D.toInt()
                else -> 0xFF8E8E93.toInt()
            })
            autoBtn.setImageResource(if (running) R.drawable.ic_pause else R.drawable.ic_play)
            autoBtn.background = ripple(if (running) 0xFF2EB67D.toInt() else 0x33FFFFFF)
        }
    }

    private fun toast(s: String) = main.post { Toast.makeText(this, s, Toast.LENGTH_SHORT).show() }

    private fun copyToClipboard(text: String, msg: String) {
        getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ترجمة", text))
        toast(msg)
    }

    /** نسخ الترجمة الأخيرة. */
    private fun copyTrans() {
        if (lastTrans.isEmpty()) { toast("لا توجد ترجمة لنسخها"); return }
        copyToClipboard(lastTrans, "تم نسخ الترجمة")
    }

    /** نسخ النص الأصلي، حتى دون ترجمة، فيُقرأ من الشاشة الآن إن لم يوجد نص محفوظ. */
    private fun copyOriginal() {
        if (lastOrig.isNotEmpty()) { copyToClipboard(lastOrig, "تم نسخ النص الأصلي"); return }
        scope.launch {
            val text = ocrText()
            if (text.isEmpty()) toast("لم أجد نصاً على الشاشة")
            else { lastOrig = text; copyToClipboard(text, "تم نسخ النص الأصلي") }
        }
    }

    private suspend fun ocrText(): String {
        val bmp = grab() ?: return ""
        val sel = Prefs.p(this).getString("src", "auto")!!
        val src = if (sel == "auto") detect(bmp) else sel
        val res = recognizer(src).process(InputImage.fromBitmap(bmp, 0)).await()
        return res.textBlocks.joinToString("\n") { b -> b.lines.joinToString(" ") { it.text } }.trim()
    }

    /** لوحة نص قابلة للتحديد والنسخ: النص الأصلي والترجمة. */
    private fun showTextPanel() {
        if (textPanelView != null) return
        fun section(title: String, body: String) = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            addView(TextView(this@OverlayService).apply {
                text = title; textSize = 13f; setTextColor(0xFF6B6F85.toInt()); setPadding(0, dp(8), 0, dp(4))
            })
            addView(TextView(this@OverlayService).apply {
                text = body.ifEmpty { "—" }; textSize = 16f; setTextIsSelectable(true)
                setTextColor(0xFF1B1D2A.toInt()); setLineSpacing(0f, 1.25f)
            })
        }
        val content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(16), dp(8), dp(16), dp(8))
            addView(section("النص الأصلي", lastOrig))
            addView(section("الترجمة", lastTrans))
        }
        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = Ui.round(0xFFFFFFFF.toInt(), dp(24).toFloat())
            setPadding(dp(12), dp(12), dp(12), dp(12))
            addView(ScrollView(this@OverlayService).apply { addView(content) },
                LinearLayout.LayoutParams(-1, dp(340)))
            addView(Ui.btn(this@OverlayService, "نسخ الترجمة").apply { setOnClickListener { copyTrans() } })
            addView(Ui.btn(this@OverlayService, "نسخ النص الأصلي", false).apply { setOnClickListener { copyOriginal() } })
            addView(Ui.btn(this@OverlayService, "إغلاق", false).apply { setOnClickListener { hideTextPanel() } })
        }
        textPanelView = box
        wm.addView(box, LP(w - dp(32), LP.WRAP_CONTENT, LP.TYPE_APPLICATION_OVERLAY,
            LP.FLAG_NOT_TOUCH_MODAL or LP.FLAG_LAYOUT_IN_SCREEN, PixelFormat.TRANSLUCENT).apply { gravity = Gravity.CENTER })
    }

    private fun hideTextPanel() {
        textPanelView?.let { try { wm.removeView(it) } catch (_: Exception) {} }
        textPanelView = null
    }

    /** لمسة على الشاشة أثناء الترجمة المستمرة: إخفاء فوري ثم إعادة الترجمة عند توقف الحركة. */
    private fun onScreenTouched() {
        gen++
        main.post { overlay.clear() }
    }

    private fun toggleAuto() {
        if (auto != null) {
            auto?.cancel(); auto = null
            refreshStatus()
            return
        }
        auto = scope.launch {
            var prev: IntArray? = null
            var done: IntArray? = null
            var seen = gen
            while (isActive) {
                delay(300)
                if (gen != seen) { seen = gen; prev = null; done = null; continue }
                if (busy) continue
                val s = sig(grab() ?: continue)
                val moving = prev == null || diff(prev!!, s) > 3
                prev = s
                if (done != null && diff(done!!, s) <= 4) continue
                if (overlay.hasItems()) main.post { overlay.clear() }
                if (moving) continue
                pass()
                delay(200)
                done = grab()?.let { sig(it) }
            }
        }
        refreshStatus()
    }

    // ---------------- خط المعالجة ----------------
    private fun recognizer(src: String) = when (src) { "ja" -> ja; "ko" -> ko; "zh" -> zh; else -> latin }

    private suspend fun detect(bmp: Bitmap): String {
        val img = InputImage.fromBitmap(bmp, 0)
        val lt = latin.process(img).await().text
        if (lt.count { it in 'A'..'Z' || it in 'a'..'z' || it in 'À'..'ÿ' } >= 10) {
            val code = try { langId.identifyLanguage(lt.replace('\n', ' ')).await() } catch (e: Exception) { "und" }
            return if (code in setOf("en", "fr", "es", "de", "it", "pt")) code else "en"
        }
        if (ja.process(img).await().text.any { it in '\u3040'..'\u30ff' }) return "ja"
        if (ko.process(img).await().text.any { it in '\uac00'..'\ud7a3' }) return "ko"
        if (zh.process(img).await().text.any { it in '\u4e00'..'\u9fff' }) return "zh"
        return "en"
    }

    private fun fixCaps(t: String): String {
        if (t.any { it.isLowerCase() } || t.none { it.isUpperCase() }) return t
        return Regex("(^|[.!?…]\\s+)(\\p{L})").replace(t.lowercase()) { it.groupValues[1] + it.groupValues[2].uppercase() }
            .replace(Regex("\\bi\\b"), "I")
    }

    private suspend fun pass() {
        if (busy) return
        busy = true
        val myGen = gen
        refreshStatus()
        try {
            withContext(Dispatchers.Main) { overlay.clear() }
            val bmp = grab() ?: return
            val p = Prefs.p(this)
            val tgt = p.getString("tgt", "ar")!!
            val isAuto = p.getString("src", "auto") == "auto"
            val src = if (isAuto) (detected ?: detect(bmp).also { detected = it }) else p.getString("src", "en")!!
            if (src == tgt) return
            val res = recognizer(src).process(InputImage.fromBitmap(bmp, 0)).await()
            val barRect = Rect(barLp.x, barLp.y, barLp.x + bar.width, barLp.y + bar.height)
            val noSpace = src == "ja" || src == "zh"
            val latinLang = src != "ja" && src != "ko" && src != "zh"
            val blocks = res.textBlocks.mapNotNull { b ->
                val box = b.boundingBox ?: return@mapNotNull null
                if (Rect.intersects(box, barRect)) return@mapNotNull null
                var t = b.lines.joinToString(if (noSpace) "" else " ") { it.text }.trim()
                if (latinLang) t = fixCaps(t)
                if (t.length < 2 || t.none { it.isLetter() }) return@mapNotNull null
                Triple(b, box, t)
            }
            if (blocks.isEmpty()) { if (isAuto) detected = null; return }
            val outs = translateAll(blocks.map { it.third }, src, tgt, p)
            val dict = if (tgt == "ar") Dict.load(this) else emptyMap()
            val scale = floatArrayOf(0.8f, 1f, 1.3f)[p.getInt("size", 1).coerceIn(0, 2)]
            val fixed = p.getInt("color", 0)

            val arr = IntArray(w * h)          // شفاف افتراضياً، ويُملأ فقط فوق النص الأصلي
            val items = ArrayList<Item>()
            val origs = ArrayList<String>()
            val trans = ArrayList<String>()
            blocks.forEachIndexed { i, (b, box, orig) ->
                val tr = outs[i] ?: return@forEachIndexed
                val lines = b.lines.mapNotNull { it.boundingBox }.ifEmpty { listOf(box) }
                val lh = lines.map { it.height() }.average().toFloat()
                val pad = (lh * 0.45f).coerceIn(5f, 18f).toInt()
                // لون الفقاعة من حول الكتلة كاملة، ثم تغطية مصمتة إن كانت الخلفية منتظمة (كما في Google Translate)
                val ringRect = Rect(box.left - 6, box.top - 6, box.right + 6, box.bottom + 6)
                val ring = bgColor(bmp, ringRect)
                if (ringUniform(bmp, ringRect, ring)) {
                    fillRect(arr, Rect(box.left - pad, box.top - pad, box.right + pad, box.bottom + pad), ring)
                } else {
                    lines.forEach { l -> inpaint(bmp, arr, Rect(l.left - pad, l.top - pad, l.right + pad, l.bottom + pad)) }
                }
                val fg = if (fixed != 0) fixed else inkColor(bmp, lines, ring)
                val translated = Dict.fix(tr, dict)
                origs.add(orig); trans.add(translated)
                items.add(Item(RectF(box), translated, fg, scale, ring, lh))
            }
            if (gen != myGen) return           // المستخدم لمس الشاشة أثناء المعالجة، فنتجاهل النتيجة
            val patch = Bitmap.createBitmap(arr, w, h, Bitmap.Config.ARGB_8888)
            lastOrig = origs.joinToString("\n")
            lastTrans = trans.joinToString("\n")
            withContext(Dispatchers.Main) {
                overlay.show(patch, items)
                collapseToEdge()
            }
        } finally {
            busy = false
            refreshStatus()
        }
    }

    private fun online(): Boolean {
        val cm = getSystemService(ConnectivityManager::class.java)
        val caps = cm.getNetworkCapabilities(cm.activeNetwork) ?: return false
        return caps.hasCapability(NetworkCapabilities.NET_CAPABILITY_INTERNET)
    }

    private suspend fun translateAll(texts: List<String>, src: String, tgt: String, p: SharedPreferences): List<String?> {
        val key = "$src>$tgt>"
        if (cache.size > 400) cache.clear()
        val out = arrayOfNulls<String>(texts.size)
        val todo = ArrayList<Int>()
        texts.forEachIndexed { i, t -> val c = cache[key + t]; if (c != null) out[i] = c else todo.add(i) }
        if (todo.isNotEmpty()) {
            val q = todo.map { texts[it] }
            val k = p.getString("apikey", "")!!.trim()
            val eng = p.getInt("engine", 2)                       // 0 جهاز، 1 إنترنت، 2 تلقائي
            val useCloud = k.isNotEmpty() && (eng == 1 || (eng == 2 && online()))
            val cloudRes = if (useCloud) withContext(Dispatchers.IO) { cloud(q, src, tgt, k) } else null
            val res: List<String?> = cloudRes ?: run {             // احتياطي: الترجمة على الجهاز
                val tr = translator(src, tgt)
                coroutineScope {
                    q.map { t -> async { try { tr.translate(t).await() } catch (e: Exception) { null } } }.awaitAll()
                }
            }
            todo.forEachIndexed { j, i -> val r = res[j]; if (r != null) { out[i] = r; cache[key + texts[i]] = r } }
        }
        return out.toList()
    }

    private fun cloud(texts: List<String>, src: String, tgt: String, key: String): List<String>? = try {
        val body = texts.joinToString("&") { "q=" + URLEncoder.encode(it, "UTF-8") } +
            "&target=$tgt&source=$src&format=text"
        val con = URL("https://translation.googleapis.com/language/translate/v2?key=" + URLEncoder.encode(key, "UTF-8"))
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 8000; con.readTimeout = 15000
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        con.outputStream.use { it.write(body.toByteArray()) }
        if (con.responseCode != 200) null else {
            val arr = JSONObject(con.inputStream.bufferedReader().readText())
                .getJSONObject("data").getJSONArray("translations")
            List(arr.length()) { arr.getJSONObject(it).getString("translatedText") }
        }
    } catch (e: Exception) { null }

    private suspend fun translator(src: String, tgt: String): Translator {
        val t = translators.getOrPut("$src>$tgt") {
            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        }
        t.downloadModelIfNeeded().await()
        return t
    }

    // ---------------- التمويه ----------------
    private fun mix(a: Int, b: Int, t: Float): Int = Color.rgb(
        (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt(),
        (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt(),
        (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt())

    private fun fillRect(dst: IntArray, r: Rect, color: Int) {
        val x0 = r.left.coerceIn(0, w - 1); val x1 = r.right.coerceIn(0, w - 1)
        val y0 = r.top.coerceIn(0, h - 1); val y1 = r.bottom.coerceIn(0, h - 1)
        for (y in y0..y1) for (x in x0..x1) dst[y * w + x] = color
    }

    /** يتحقق من أن حواف المنطقة لها لون واحد تقريباً، أي أن الفقاعة منتظمة اللون. */
    private fun ringUniform(b: Bitmap, r: Rect, ref: Int): Boolean {
        val l = r.left.coerceIn(0, b.width - 1); val rr = r.right.coerceIn(0, b.width - 1)
        val t = r.top.coerceIn(0, b.height - 1); val bt = r.bottom.coerceIn(0, b.height - 1)
        var n = 0; var bad = 0
        var x = l
        while (x <= rr) {
            if (dist(b.getPixel(x, t), ref) > 90) bad++
            if (dist(b.getPixel(x, bt), ref) > 90) bad++
            n += 2; x += 4
        }
        var y = t
        while (y <= bt) {
            if (dist(b.getPixel(l, y), ref) > 90) bad++
            if (dist(b.getPixel(rr, y), ref) > 90) bad++
            n += 2; y += 4
        }
        return n > 0 && bad * 5 < n
    }

    /** للخلفيات المتدرجة (الرسوم): يملأ كل سطر بتدرج من حوافه. */
    private fun inpaint(src: Bitmap, dst: IntArray, r: Rect) {
        val W = src.width; val H = src.height
        val x0 = r.left.coerceIn(1, W - 2); val x1 = r.right.coerceIn(1, W - 2)
        val y0 = r.top.coerceIn(1, H - 2); val y1 = r.bottom.coerceIn(1, H - 2)
        if (x1 <= x0 || y1 <= y0) return
        val top = IntArray(x1 - x0 + 1) { src.getPixel(x0 + it, y0 - 1) }
        val bot = IntArray(x1 - x0 + 1) { src.getPixel(x0 + it, y1 + 1) }
        val fw = (x1 - x0).toFloat(); val fh = (y1 - y0).toFloat()
        for (y in y0..y1) {
            val lc = src.getPixel(x0 - 1, y); val rc = src.getPixel(x1 + 1, y)
            val s = (y - y0) / fh
            for (x in x0..x1) {
                val t = (x - x0) / fw
                dst[y * W + x] = mix(mix(lc, rc, t), mix(top[x - x0], bot[x - x0], s), 0.5f)
            }
        }
    }

    // ---------------- الألوان ----------------
    private fun dist(a: Int, b: Int) =
        abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))

    private fun contrast(bg: Int) =
        if ((Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 > 140) Color.BLACK else Color.WHITE

    private fun mode(px: List<Int>): Int {
        if (px.isEmpty()) return Color.WHITE
        val m = HashMap<Int, IntArray>()
        for (c in px) {
            val k = (Color.red(c) shr 4 shl 8) or (Color.green(c) shr 4 shl 4) or (Color.blue(c) shr 4)
            val a = m.getOrPut(k) { IntArray(4) }
            a[0]++; a[1] += Color.red(c); a[2] += Color.green(c); a[3] += Color.blue(c)
        }
        val best = m.values.maxByOrNull { it[0] }!!
        return Color.rgb(best[1] / best[0], best[2] / best[0], best[3] / best[0])
    }

    private fun bgColor(b: Bitmap, r: Rect): Int {
        val l = (r.left - 3).coerceIn(0, b.width - 1)
        val rr = (r.right + 3).coerceIn(0, b.width - 1)
        val t = (r.top - 3).coerceIn(0, b.height - 1)
        val bt = (r.bottom + 3).coerceIn(0, b.height - 1)
        val px = ArrayList<Int>()
        var x = l
        while (x <= rr) { px.add(b.getPixel(x, t)); px.add(b.getPixel(x, bt)); x += 4 }
        var y = t
        while (y <= bt) { px.add(b.getPixel(l, y)); px.add(b.getPixel(rr, y)); y += 4 }
        return mode(px)
    }

    private fun inkColor(b: Bitmap, lines: List<Rect>, bg: Int): Int {
        var n = 0; var r = 0L; var g = 0L; var bl = 0L
        for (ln in lines) {
            var y = ln.top.coerceAtLeast(0)
            while (y < ln.bottom.coerceAtMost(b.height)) {
                var x = ln.left.coerceAtLeast(0)
                while (x < ln.right.coerceAtMost(b.width)) {
                    val c = b.getPixel(x, y)
                    if (dist(c, bg) > 360) { n++; r += Color.red(c); g += Color.green(c); bl += Color.blue(c) }
                    x += 2
                }
                y += 2
            }
        }
        if (n < 6) return contrast(bg)
        val ink = Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
        return if (dist(ink, bg) < 250) contrast(bg) else ink
    }

    // ---------------- التقاط الشاشة ----------------
    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val p = img.planes[0]
            val rw = p.rowStride / p.pixelStride
            val b = Bitmap.createBitmap(rw, h, Bitmap.Config.ARGB_8888)
            b.copyPixelsFromBuffer(p.buffer)
            img.close()
            cached = if (rw == w) b else Bitmap.createBitmap(b, 0, 0, w, h)
        }
        return cached
    }

    private fun sig(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 24, 40, true)
        val a = IntArray(960)
        s.getPixels(a, 0, 24, 0, 0, 24, 40)
        return IntArray(960) { val c = a[it]; (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
    }

    private fun diff(a: IntArray, b: IntArray): Int {
        var d = 0L
        for (i in a.indices) d += abs(a[i] - b[i])
        return (d / a.size).toInt()
    }

    override fun onDestroy() {
        auto?.cancel(); scope.cancel()
        Prefs.p(this).edit().putBoolean("running", false).apply()
        try { wm.removeView(bar); wm.removeView(overlay); wm.removeView(watcher) } catch (_: Exception) {}
        hideTextPanel()
        vd?.release(); reader?.close(); proj?.stop()
        translators.values.forEach { it.close() }
        super.onDestroy()
    }
}
