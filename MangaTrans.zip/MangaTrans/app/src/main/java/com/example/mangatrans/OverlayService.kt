package com.example.mangatrans

import android.app.*
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.view.WindowManager.LayoutParams as LP
import android.widget.ImageView
import android.widget.LinearLayout
import com.google.mlkit.nl.languageid.LanguageIdentification
import com.google.mlkit.nl.translate.*
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.chinese.ChineseTextRecognizerOptions
import com.google.mlkit.vision.text.japanese.JapaneseTextRecognizerOptions
import com.google.mlkit.vision.text.korean.KoreanTextRecognizerOptions
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlinx.coroutines.*
import kotlinx.coroutines.tasks.await
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import kotlin.math.abs

@Suppress("DEPRECATION")
class OverlayService : Service() {
    private lateinit var wm: WindowManager
    private var proj: MediaProjection? = null
    private var reader: ImageReader? = null
    private var vd: VirtualDisplay? = null
    private lateinit var overlay: TranslationOverlayView
    private lateinit var bar: LinearLayout
    private lateinit var panel: LinearLayout
    private lateinit var barLp: LP
    private lateinit var one: ImageView
    private lateinit var autoBtn: ImageView
    private val main = Handler(Looper.getMainLooper())
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Default)
    private var auto: Job? = null
    @Volatile private var busy = false
    private var w = 0
    private var h = 0
    private var cached: Bitmap? = null
    private var detected: String? = null
    private val cache = HashMap<String, String>()

    private val latin by lazy { TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS) }
    private val ja by lazy { TextRecognition.getClient(JapaneseTextRecognizerOptions.Builder().build()) }
    private val ko by lazy { TextRecognition.getClient(KoreanTextRecognizerOptions.Builder().build()) }
    private val zh by lazy { TextRecognition.getClient(ChineseTextRecognizerOptions.Builder().build()) }
    private val langId by lazy { LanguageIdentification.getClient() }
    private val translators = HashMap<String, Translator>()

    override fun onBind(i: Intent?): IBinder? = null
    override fun onCreate() { super.onCreate(); wm = getSystemService(WINDOW_SERVICE) as WindowManager }

    override fun onStartCommand(i: Intent?, f: Int, id: Int): Int {
        if (proj != null || i == null) return START_NOT_STICKY
        getSystemService(NotificationManager::class.java)
            .createNotificationChannel(NotificationChannel("c", "MangaTrans", NotificationManager.IMPORTANCE_LOW))
        val n = Notification.Builder(this, "c").setContentTitle("مترجم المانهوا يعمل")
            .setSmallIcon(android.R.drawable.ic_menu_camera).build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        val data: Intent = if (Build.VERSION.SDK_INT >= 33) i.getParcelableExtra("data", Intent::class.java)!!
        else i.getParcelableExtra("data")!!
        proj = getSystemService(MediaProjectionManager::class.java).getMediaProjection(i.getIntExtra("code", 0), data)
        proj!!.registerCallback(object : MediaProjection.Callback() { override fun onStop() { stopSelf() } }, main)
        val dm = DisplayMetrics()
        wm.defaultDisplay.getRealMetrics(dm)
        w = dm.widthPixels; h = dm.heightPixels
        reader = ImageReader.newInstance(w, h, PixelFormat.RGBA_8888, 2)
        vd = proj!!.createVirtualDisplay("cap", w, h, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null)
        buildUi()
        return START_NOT_STICKY
    }

    // ---------------- الواجهة العائمة ----------------
    private fun dp(v: Int) = Ui.dp(this, v)
    private fun circle(c: Int) = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(c) }
    private fun icon(res: Int, bg: Int) = ImageView(this).apply {
        setImageResource(res); setColorFilter(Color.WHITE)
        setPadding(dp(11), dp(11), dp(11), dp(11))
        background = circle(bg)
        layoutParams = LinearLayout.LayoutParams(dp(46), dp(46)).apply { marginStart = dp(6) }
    }

    private fun buildUi() {
        val t = LP.TYPE_APPLICATION_OVERLAY
        overlay = TranslationOverlayView(this)
        wm.addView(overlay, LP(w, h, t,
            LP.FLAG_NOT_FOCUSABLE or LP.FLAG_NOT_TOUCHABLE or LP.FLAG_LAYOUT_IN_SCREEN or LP.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START })

        val handle = ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(dp(11), dp(11), dp(11), dp(11))
            background = circle(Ui.ACCENT)
            layoutParams = LinearLayout.LayoutParams(dp(50), dp(50))
        }
        one = icon(R.drawable.ic_eye, 0x33FFFFFF)
        autoBtn = icon(R.drawable.ic_play, 0x33FFFFFF)
        val closeBtn = icon(R.drawable.ic_close, 0x66FF3B30)
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            addView(one); addView(autoBtn); addView(closeBtn)
        }
        bar = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            background = Ui.round(0xE61E1E2C.toInt(), dp(40).toFloat())
            setPadding(dp(4), dp(4), dp(8), dp(4))
            addView(handle); addView(panel)
        }
        barLp = LP(LP.WRAP_CONTENT, LP.WRAP_CONTENT, t, LP.FLAG_NOT_FOCUSABLE or LP.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT).apply { gravity = Gravity.TOP or Gravity.START; x = 20; y = 300 }
        wm.addView(bar, barLp)

        // السحب بالأيقونة الرئيسية، والضغطة القصيرة تطوي/تفتح الأزرار
        var sx = 0f; var sy = 0f; var ox = 0; var oy = 0; var moved = false
        handle.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> { sx = e.rawX; sy = e.rawY; ox = barLp.x; oy = barLp.y; moved = false }
                MotionEvent.ACTION_MOVE -> {
                    val dx = e.rawX - sx; val dy = e.rawY - sy
                    if (abs(dx) > 12 || abs(dy) > 12) moved = true
                    if (moved) { barLp.x = ox + dx.toInt(); barLp.y = oy + dy.toInt(); wm.updateViewLayout(bar, barLp) }
                }
                MotionEvent.ACTION_UP -> if (!moved) {
                    panel.visibility = if (panel.visibility == View.VISIBLE) View.GONE else View.VISIBLE
                    wm.updateViewLayout(bar, barLp)
                }
            }
            true
        }
        one.setOnClickListener { if (overlay.hasItems()) overlay.setItems(emptyList()) else scope.launch { pass() } }
        autoBtn.setOnClickListener { toggleAuto() }
        closeBtn.setOnClickListener { stopSelf() }
    }

    private fun toggleAuto() {
        if (auto != null) {
            auto?.cancel(); auto = null
            autoBtn.setImageResource(R.drawable.ic_play); autoBtn.background = circle(0x33FFFFFF)
            return
        }
        autoBtn.setImageResource(R.drawable.ic_pause); autoBtn.background = circle(0xFF2EB67D.toInt())
        auto = scope.launch {
            var prev: IntArray? = null
            var done: IntArray? = null
            while (isActive) {
                delay(350)
                if (busy) continue
                val s = sig(grab() ?: continue)
                val moving = prev == null || diff(prev, s) > 3
                prev = s
                if (done != null && diff(done, s) <= 4) continue
                if (overlay.hasItems()) main.post { overlay.setItems(emptyList()) }
                if (moving) continue
                pass()
                delay(250)
                done = grab()?.let { sig(it) }
            }
        }
    }

    // ---------------- خط المعالجة ----------------
    private fun recognizer(src: String) = when (src) { "ja" -> ja; "ko" -> ko; "zh" -> zh; else -> latin }

    private suspend fun detect(bmp: Bitmap): String {
        val img = InputImage.fromBitmap(bmp, 0)
        val lt = latin.process(img).await().text
        if (lt.count { it in 'A'..'Z' || it in 'a'..'z' || it in 'À'..'ÿ' } >= 10) {
            val code = try { langId.identifyLanguage(lt.replace('\n', ' ')).await() } catch (e: Exception) { "und" }
            return if (code in setOf("en", "fr", "es", "de", "it", "pt")) code else "en"
        }
        if (ja.process(img).await().text.any { it in '\u3040'..'\u30ff' }) return "ja"
        if (ko.process(img).await().text.any { it in '\uac00'..'\ud7a3' }) return "ko"
        if (zh.process(img).await().text.any { it in '\u4e00'..'\u9fff' }) return "zh"
        return "en"
    }

    // النصوص الإنجليزية في المانغا بحروف كبيرة؛ تحويلها لحروف عادية يحسّن الترجمة كثيراً
    private fun fixCaps(t: String): String {
        if (t.any { it.isLowerCase() } || t.none { it.isUpperCase() }) return t
        return Regex("(^|[.!?…]\\s+)(\\p{L})").replace(t.lowercase()) { it.groupValues[1] + it.groupValues[2].uppercase() }
            .replace(Regex("\\bi\\b"), "I")
    }

    private suspend fun pass() {
        if (busy) return
        busy = true
        main.post { one.alpha = 0.4f }
        try {
            val had = withContext(Dispatchers.Main) { val x = overlay.hasItems(); overlay.setItems(emptyList()); x }
            if (had) delay(220)
            val bmp = grab() ?: return
            val p = Prefs.p(this)
            val tgt = p.getString("tgt", "ar")!!
            val isAuto = p.getString("src", "auto") == "auto"
            val src = if (isAuto) (detected ?: detect(bmp).also { detected = it }) else p.getString("src", "en")!!
            if (src == tgt) return
            val res = recognizer(src).process(InputImage.fromBitmap(bmp, 0)).await()
            val barRect = Rect(barLp.x, barLp.y, barLp.x + bar.width, barLp.y + bar.height)
            val noSpace = src == "ja" || src == "zh"
            val latinLang = src != "ja" && src != "ko" && src != "zh"
            val blocks = res.textBlocks.mapNotNull { b ->
                val box = b.boundingBox ?: return@mapNotNull null
                if (Rect.intersects(box, barRect)) return@mapNotNull null
                var t = b.lines.joinToString(if (noSpace) "" else " ") { it.text }.trim()
                if (latinLang) t = fixCaps(t)
                if (t.length < 2 || t.none { it.isLetter() }) return@mapNotNull null
                Triple(b, box, t)
            }
            if (blocks.isEmpty()) { if (isAuto) detected = null; return }
            val outs = translateAll(blocks.map { it.third }, src, tgt, p)
            val dict = if (tgt == "ar") Dict.load(this) else emptyMap()
            val scale = floatArrayOf(0.8f, 1f, 1.3f)[p.getInt("size", 1).coerceIn(0, 2)]
            val fixed = p.getInt("color", 0)
            val items = blocks.mapIndexedNotNull { i, (b, box, _) ->
                val tr = outs[i] ?: return@mapIndexedNotNull null
                val lines = b.lines.mapNotNull { it.boundingBox }.ifEmpty { listOf(box) }
                val lh = lines.map { it.height() }.average().toFloat()
                val pad = (lh * 0.2f).coerceIn(3f, 12f)
                val lr = lines.map { l ->
                    val rf = RectF(l.left - pad, l.top - pad * 0.6f, l.right + pad, l.bottom + pad * 0.6f)
                    rf to bgColor(bmp, rf)
                }
                val fg = if (fixed != 0) fixed else inkColor(bmp, lines, lr.first().second)
                Item(lr, RectF(box), Dict.fix(tr, dict), fg, scale)
            }
            withContext(Dispatchers.Main) { overlay.setItems(items) }
        } finally {
            busy = false
            main.post { one.alpha = 1f }
        }
    }

    private suspend fun translateAll(texts: List<String>, src: String, tgt: String, p: SharedPreferences): List<String?> {
        val key = "$src>$tgt>"
        if (cache.size > 400) cache.clear()
        val out = arrayOfNulls<String>(texts.size)
        val todo = ArrayList<Int>()
        texts.forEachIndexed { i, t -> val c = cache[key + t]; if (c != null) out[i] = c else todo.add(i) }
        if (todo.isNotEmpty()) {
            val q = todo.map { texts[it] }
            val k = p.getString("apikey", "")!!.trim()
            val cloudRes = if (p.getInt("engine", 0) == 1 && k.isNotEmpty())
                withContext(Dispatchers.IO) { cloud(q, src, tgt, k) } else null
            val res: List<String?> = cloudRes ?: run {
                val tr = translator(src, tgt)
                coroutineScope {
                    q.map { t -> async { try { tr.translate(t).await() } catch (e: Exception) { null } } }.awaitAll()
                }
            }
            todo.forEachIndexed { j, i -> val r = res[j]; if (r != null) { out[i] = r; cache[key + texts[i]] = r } }
        }
        return out.toList()
    }

    private fun cloud(texts: List<String>, src: String, tgt: String, key: String): List<String>? = try {
        val body = texts.joinToString("&") { "q=" + URLEncoder.encode(it, "UTF-8") } +
            "&target=$tgt&source=$src&format=text"
        val con = URL("https://translation.googleapis.com/language/translate/v2?key=" + URLEncoder.encode(key, "UTF-8"))
            .openConnection() as HttpURLConnection
        con.requestMethod = "POST"; con.doOutput = true; con.connectTimeout = 8000; con.readTimeout = 15000
        con.setRequestProperty("Content-Type", "application/x-www-form-urlencoded")
        con.outputStream.use { it.write(body.toByteArray()) }
        if (con.responseCode != 200) null else {
            val arr = JSONObject(con.inputStream.bufferedReader().readText())
                .getJSONObject("data").getJSONArray("translations")
            List(arr.length()) { arr.getJSONObject(it).getString("translatedText") }
        }
    } catch (e: Exception) { null }

    private suspend fun translator(src: String, tgt: String): Translator {
        val t = translators.getOrPut("$src>$tgt") {
            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
        }
        t.downloadModelIfNeeded().await()
        return t
    }

    // ---------------- الألوان ----------------
    private fun dist(a: Int, b: Int) =
        abs(Color.red(a) - Color.red(b)) + abs(Color.green(a) - Color.green(b)) + abs(Color.blue(a) - Color.blue(b))

    private fun contrast(bg: Int) =
        if ((Color.red(bg) * 299 + Color.green(bg) * 587 + Color.blue(bg) * 114) / 1000 > 140) Color.BLACK else Color.WHITE

    private fun mode(px: List<Int>): Int {
        if (px.isEmpty()) return Color.WHITE
        val m = HashMap<Int, IntArray>()
        for (c in px) {
            val k = (Color.red(c) shr 4 shl 8) or (Color.green(c) shr 4 shl 4) or (Color.blue(c) shr 4)
            val a = m.getOrPut(k) { IntArray(4) }
            a[0]++; a[1] += Color.red(c); a[2] += Color.green(c); a[3] += Color.blue(c)
        }
        val best = m.values.maxByOrNull { it[0] }!!
        return Color.rgb(best[1] / best[0], best[2] / best[0], best[3] / best[0])
    }

    /** لون الخلفية: اللون الأكثر تكراراً على إطار يحيط بالنص. */
    private fun bgColor(b: Bitmap, r: RectF): Int {
        val l = (r.left - 3).toInt().coerceIn(0, b.width - 1)
        val rr = (r.right + 3).toInt().coerceIn(0, b.width - 1)
        val t = (r.top - 3).toInt().coerceIn(0, b.height - 1)
        val bt = (r.bottom + 3).toInt().coerceIn(0, b.height - 1)
        val px = ArrayList<Int>()
        var x = l
        while (x <= rr) { px.add(b.getPixel(x, t)); px.add(b.getPixel(x, bt)); x += 4 }
        var y = t
        while (y <= bt) { px.add(b.getPixel(l, y)); px.add(b.getPixel(rr, y)); y += 4 }
        return mode(px)
    }

    /** لون حبر النص الأصلي: متوسط البكسلات المختلفة بقوة عن الخلفية داخل الأسطر. */
    private fun inkColor(b: Bitmap, lines: List<Rect>, bg: Int): Int {
        var n = 0; var r = 0L; var g = 0L; var bl = 0L
        for (ln in lines) {
            var y = ln.top.coerceAtLeast(0)
            while (y < ln.bottom.coerceAtMost(b.height)) {
                var x = ln.left.coerceAtLeast(0)
                while (x < ln.right.coerceAtMost(b.width)) {
                    val c = b.getPixel(x, y)
                    if (dist(c, bg) > 360) { n++; r += Color.red(c); g += Color.green(c); bl += Color.blue(c) }
                    x += 2
                }
                y += 2
            }
        }
        if (n < 6) return contrast(bg)
        val ink = Color.rgb((r / n).toInt(), (g / n).toInt(), (bl / n).toInt())
        return if (dist(ink, bg) < 250) contrast(bg) else ink
    }

    // ---------------- التقاط الشاشة ----------------
    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage()
        if (img != null) {
            val p = img.planes[0]
            val rw = p.rowStride / p.pixelStride
            val b = Bitmap.createBitmap(rw, h, Bitmap.Config.ARGB_8888)
            b.copyPixelsFromBuffer(p.buffer)
            img.close()
            cached = if (rw == w) b else Bitmap.createBitmap(b, 0, 0, w, h)
        }
        return cached
    }

    private fun sig(b: Bitmap): IntArray {
        val s = Bitmap.createScaledBitmap(b, 24, 40, true)
        val a = IntArray(960)
        s.getPixels(a, 0, 24, 0, 0, 24, 40)
        return IntArray(960) { val c = a[it]; (Color.red(c) + Color.green(c) + Color.blue(c)) / 3 }
    }

    private fun diff(a: IntArray, b: IntArray): Int {
        var d = 0L
        for (i in a.indices) d += abs(a[i] - b[i])
        return (d / a.size).toInt()
    }

    override fun onDestroy() {
        auto?.cancel(); scope.cancel()
        try { wm.removeView(bar); wm.removeView(overlay) } catch (_: Exception) {}
        vd?.release(); reader?.close(); proj?.stop()
        translators.values.forEach { it.close() }
        super.onDestroy()
    }
}
