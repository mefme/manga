package com.example.mangatrans

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await

class MainActivity : ComponentActivity() {
    private val prefs by lazy { getSharedPreferences("p", 0) }
    private lateinit var list: LinearLayout

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", d))
            Toast.makeText(this, "الأيقونة العائمة تعمل. افتح تطبيق القراءة", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        if (!prefs.getBoolean("seeded", false)) {
            Dict.save(this, linkedMapOf("إله" to "حاكم", "ملاك" to "مجنح", "شيطان" to "عفريت"))
            prefs.edit().putBoolean("seeded", true).apply()
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(40, 60, 40, 40) }
        fun tv(t: String, sz: Float = 16f) = TextView(this).apply { text = t; textSize = sz; setPadding(0, 24, 0, 10) }

        root.addView(tv("لغة المانهوا / المانغا", 18f))
        val rg = RadioGroup(this)
        listOf("en" to "إنجليزي", "ja" to "ياباني", "ko" to "كوري").forEach { (k, n) ->
            rg.addView(RadioButton(this).apply {
                text = n; id = View.generateViewId()
                isChecked = prefs.getString("src", "en") == k
                setOnClickListener { prefs.edit().putString("src", k).apply() }
            })
        }
        root.addView(rg)

        root.addView(Button(this).apply {
            text = "1) تحميل نماذج الترجمة (مرة واحدة، يحتاج إنترنت)"
            setOnClickListener {
                Toast.makeText(context, "جاري التحميل...", Toast.LENGTH_SHORT).show()
                lifecycleScope.launch {
                    try {
                        for (c in listOf(TranslateLanguage.ENGLISH, TranslateLanguage.JAPANESE, TranslateLanguage.KOREAN)) {
                            Translation.getClient(TranslatorOptions.Builder().setSourceLanguage(c)
                                .setTargetLanguage(TranslateLanguage.ARABIC).build()).downloadModelIfNeeded().await()
                        }
                        Toast.makeText(context, "تم التحميل ✓", Toast.LENGTH_LONG).show()
                    } catch (e: Exception) { Toast.makeText(context, "فشل التحميل: تحقق من الإنترنت", Toast.LENGTH_LONG).show() }
                }
            }
        })
        root.addView(Button(this).apply {
            text = "2) تشغيل الأيقونة العائمة"
            setOnClickListener {
                if (!Settings.canDrawOverlays(context)) {
                    startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
                    Toast.makeText(context, "فعّل «العرض فوق التطبيقات» ثم ارجع واضغط مجدداً", Toast.LENGTH_LONG).show()
                    return@setOnClickListener
                }
                if (Build.VERSION.SDK_INT >= 33 &&
                    checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
                    requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
                capture.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
            }
        })

        root.addView(tv("القاموس المخصص", 18f))
        val from = EditText(this).apply { hint = "الكلمة في الترجمة (مثال: إله)" }
        val to = EditText(this).apply { hint = "البديل (مثال: حاكم)" }
        root.addView(from); root.addView(to)
        root.addView(Button(this).apply {
            text = "إضافة"
            setOnClickListener {
                val a = from.text.toString().trim(); val b = to.text.toString().trim()
                if (a.isNotEmpty() && b.isNotEmpty()) {
                    val m = Dict.load(context); m[a] = b; Dict.save(context, m)
                    from.text.clear(); to.text.clear(); refresh()
                }
            }
        })
        root.addView(tv("اضغط مطولاً على أي سطر لحذفه:", 14f))
        list = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        root.addView(list)
        setContentView(ScrollView(this).apply { addView(root) })
        refresh()
    }

    private fun refresh() {
        list.removeAllViews()
        for ((k, v) in Dict.load(this)) {
            list.addView(TextView(this).apply {
                text = "$k  ←  $v"; textSize = 18f; setPadding(0, 16, 0, 16)
                setOnLongClickListener {
                    val m = Dict.load(context); m.remove(k); Dict.save(context, m); refresh(); true
                }
            })
        }
    }
}
