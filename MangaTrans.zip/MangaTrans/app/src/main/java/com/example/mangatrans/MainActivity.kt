package com.example.mangatrans

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val d = r.data
        if (r.resultCode == RESULT_OK && d != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", d))
            Toast.makeText(this, "الأيقونة العائمة تعمل. افتح تطبيق القراءة", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        Dict.seed(this)
        val d = { v: Int -> Ui.dp(this, v) }
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; gravity = Gravity.CENTER
            setBackgroundColor(0xFFF4F5FB.toInt()); setPadding(d(32), d(32), d(32), d(32))
        }
        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(d(26), d(26), d(26), d(26))
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(Ui.ACCENT) }
            layoutParams = LinearLayout.LayoutParams(d(110), d(110))
        })
        root.addView(TextView(this).apply {
            text = "مترجم المانهوا"; textSize = 28f; gravity = Gravity.CENTER
            setTextColor(0xFF1B1D2A.toInt()); setPadding(0, d(20), 0, d(4))
        })
        root.addView(TextView(this).apply {
            text = "ترجمة فورية أثناء التصفح"; textSize = 16f; gravity = Gravity.CENTER
            setTextColor(0xFF6B6F85.toInt()); setPadding(0, 0, 0, d(32))
        })
        root.addView(Ui.btn(this, "تشغيل الأيقونة العائمة").apply { setOnClickListener { start() } })
        root.addView(Ui.btn(this, "الإعدادات", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        setContentView(root)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع واضغط مجدداً", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        capture.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}
