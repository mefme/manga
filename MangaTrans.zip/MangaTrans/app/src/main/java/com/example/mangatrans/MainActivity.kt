package com.example.mangatrans

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.view.Gravity
import android.text.Editable
import android.text.TextWatcher
import android.widget.AdapterView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import com.google.mlkit.nl.languageid.LanguageIdentification
import android.content.ClipData
import android.content.ClipboardManager
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Locale
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var statusTv: TextView
    private lateinit var permTv: TextView
    private lateinit var toggleBtn: TextView
    private fun d(v: Int) = Ui.dp(this, v)
    private fun col(id: Int) = getColor(id)

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", data))
            Toast.makeText(this, "الفقاعة تعمل. افتح تطبيق القراءة", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        Dict.seed(this)
        val prevHandler = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, ex ->
            try { java.io.File(filesDir, "crash.txt").writeText(ex.stackTraceToString()) } catch (_: Exception) {}
            prevHandler?.uncaughtException(t, ex)
        }
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(28), d(20), d(32)) }

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(d(18), d(18), d(18), d(18))
            background = Ui.round(Ui.ACCENT, d(24).toFloat())
            layoutParams = LinearLayout.LayoutParams(d(72), d(72))
        })
        root.addView(TextView(this).apply {
            text = "مترجم المانهوا"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(col(R.color.text)); setPadding(0, d(14), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "ترجمة فورية فوق المانهوا والمانغا"; textSize = 15f
            setTextColor(col(R.color.subtext)); setPadding(0, d(4), 0, d(8))
        })

        val status = Ui.card(this, "الحالة")
        statusTv = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, d(4), 0, 0) }
        permTv = Ui.note(this, "")
        toggleBtn = Ui.btn(this, "")
        status.addView(statusTv); status.addView(permTv); status.addView(toggleBtn)
        root.addView(status)
        root.addView(translateCard())
        val crashFile = java.io.File(filesDir, "crash.txt")
        if (crashFile.exists()) {
            val crashCard = Ui.card(this, "آخر خطأ حدث في التطبيق")
            val crashText = crashFile.readText()
            crashCard.addView(TextView(this).apply {
                text = crashText.take(1500); textSize = 11f; setTextIsSelectable(true); setTextColor(col(R.color.subtext))
            })
            crashCard.addView(Ui.btn(this, "نسخ الخطأ", false).apply {
                setOnClickListener {
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("خطأ", crashText))
                    Toast.makeText(this@MainActivity, "تم نسخ الخطأ", Toast.LENGTH_SHORT).show()
                }
            })
            crashCard.addView(Ui.btn(this, "مسح السجل", false).apply {
                setOnClickListener { crashFile.delete(); recreate() }
            })
            root.addView(crashCard, 0)
        }

        val steps = Ui.card(this, "طريقة الاستخدام")
        listOf(
            "نزّل لغات الترجمة من الإعدادات مرة واحدة، وهذا يحتاج إنترنت.",
            "شغّل الفقاعة وامنح الصلاحيات المطلوبة.",
            "افتح تطبيق المانهوا، واضغط 👁 للترجمة مرة، أو ▶ للترجمة المستمرة."
        ).forEachIndexed { i, text -> steps.addView(Ui.note(this, "${i + 1}. $text")) }
        root.addView(steps)

        root.addView(TextView(this).apply {
            text = "نسخة البناء: tr-21"; textSize = 12f; gravity = android.view.Gravity.CENTER
            setTextColor(col(R.color.subtext)); setPadding(0, d(16), 0, 0)
        })
        root.addView(Ui.btn(this, "الإعدادات", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(col(R.color.bg)); addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val running = Prefs.p(this).getBoolean("running", false)
        statusTv.text = if (running) "● الفقاعة تعمل" else "○ الفقاعة متوقفة"
        statusTv.setTextColor(if (running) 0xFF2EB67D.toInt() else col(R.color.subtext))
        permTv.text = if (Settings.canDrawOverlays(this)) "✓ صلاحية العرض فوق التطبيقات ممنوحة"
        else "✗ تحتاج صلاحية العرض فوق التطبيقات"
        toggleBtn.text = if (running) "إيقاف الفقاعة" else "تشغيل الفقاعة"
        toggleBtn.background = Ui.round(if (running) 0xFFFF3B30.toInt() else Ui.ACCENT, 40f)
        toggleBtn.setOnClickListener { if (running) stopBubble() else start() }
    }

    /** ترجمة نص داخل التطبيق: الخانتان قابلتان للكتابة، والكتابة في الترجمة تترجم عكسياً. */
    private fun translateCard(): LinearLayout {
        val c = Ui.card(this, "ترجمة نص")
        val fromCodes = listOf("auto") + Prefs.allCodes
        val toCodes = Prefs.allCodes
        val fromAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, fromCodes.map { Prefs.langName(it) })
        val toAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, toCodes.map { Prefs.langName(it) })
        val from = Spinner(this).apply { this.adapter = fromAdapter; setSelection(0) }
        val to = Spinner(this).apply { this.adapter = toAdapter; setSelection(toCodes.indexOf("ar").coerceAtLeast(0)) }
        fun box(t: EditText): EditText = t.apply {
            textSize = 17f; setTextColor(col(R.color.text)); gravity = Gravity.TOP or Gravity.START
            setPadding(d(14), d(8), d(14), d(8)); minLines = 1; minHeight = d(48)
            background = Ui.round(col(R.color.bg), 18f)
        }
        val input = box(EditText(this).apply { hint = "اكتب أو الصق النص هنا" })
        val output = box(EditText(this).apply { hint = "الترجمة تظهر هنا" })
        output.layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(6) }
        val detected = Ui.note(this, "")
        val err = "تعذّرت الترجمة. تأكد من الإنترنت لتحميل اللغات مرة واحدة."
        var lastDetected: String? = null
        var job: Job? = null
        var reverseJob: Job? = null
        var programmatic = false

        fun setOut(t: String) { programmatic = true; output.setText(t); programmatic = false }
        fun setIn(t: String) { programmatic = true; input.setText(t); programmatic = false }

        suspend fun run(text: String, srcIn: String, tgt: String): String {
            var src = srcIn
            if (src == "auto") {
                val id = LanguageIdentification.getClient().identifyLanguage(text).await()
                if (id == "und") { detected.text = ""; return "تعذّر تحديد اللغة" }
                src = id; lastDetected = id
                detected.text = "اللغة المكتشفة: ${Prefs.langName(id)}"
            } else detected.text = ""
            if (src == tgt) return text
            val client = Translation.getClient(
                TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
            return try {
                client.downloadModelIfNeeded().await()
                client.translate(text).await()
            } finally { client.close() }
        }

        suspend fun forward() {
            val text = input.text.toString().trim()
            if (text.isEmpty()) { setOut(""); detected.text = ""; return }
            val result = try { run(text, fromCodes[from.selectedItemPosition], toCodes[to.selectedItemPosition]) }
                catch (e: Exception) { err }
            setOut(result)
        }

        suspend fun reverse() {
            val text = output.text.toString().trim()
            if (text.isEmpty()) { setIn(""); return }
            val srcNow = fromCodes[from.selectedItemPosition]
            val tgt = if (srcNow == "auto") (lastDetected ?: "en") else srcNow
            val result = try { run(text, toCodes[to.selectedItemPosition], tgt) } catch (e: Exception) { err }
            setIn(result)
        }

        fun scheduleForward() {
            job?.cancel()
            job = lifecycleScope.launch { delay(450); forward() }
        }
        fun scheduleReverse() {
            reverseJob?.cancel()
            reverseJob = lifecycleScope.launch { delay(450); reverse() }
        }

        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { scheduleForward() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        from.onItemSelectedListener = listener
        to.onItemSelectedListener = listener
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
            override fun afterTextChanged(s: Editable?) { if (!programmatic) scheduleForward() }
        })
        output.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
            override fun afterTextChanged(s: Editable?) { if (!programmatic) scheduleReverse() }
        })

        val swap = ImageView(this).apply {
            setImageResource(R.drawable.ic_swap_vert); setColorFilter(col(R.color.text))
            setPadding(d(6), d(6), d(6), d(6))
            layoutParams = LinearLayout.LayoutParams(d(36), d(36))
            setOnClickListener {
                val oldFrom = fromCodes[from.selectedItemPosition]
                val oldTo = toCodes[to.selectedItemPosition]
                val newTo = if (oldFrom == "auto") (lastDetected ?: "en") else oldFrom
                from.setSelection(fromCodes.indexOf(oldTo).coerceAtLeast(0))
                to.setSelection(toCodes.indexOf(newTo).coerceAtLeast(0))
                val out = output.text.toString()
                if (out.isNotEmpty()) setIn(out)
                scheduleForward()
            }
        }
        val swapRow = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER
            setPadding(0, d(2), 0, d(2))
            addView(swap)
        }
        val copy = Ui.btn(this, "نسخ الترجمة", false).apply {
            setOnClickListener {
                val text = output.text.toString()
                if (text.isNotEmpty()) {
                    getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ترجمة", text))
                    Toast.makeText(this@MainActivity, "تم النسخ", Toast.LENGTH_SHORT).show()
                }
            }
        }
        c.addView(from)
        c.addView(input)
        c.addView(detected)
        c.addView(swapRow)
        c.addView(to)
        c.addView(output)
        c.addView(copy)
        return c
    }

    private fun stopBubble() {
        startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        toggleBtn.postDelayed({ refresh() }, 400)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        capture.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}
