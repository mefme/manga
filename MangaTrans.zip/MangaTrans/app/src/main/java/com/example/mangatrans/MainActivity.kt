package com.example.mangatrans

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var statusTv: TextView
    private lateinit var permTv: TextView
    private lateinit var toggleBtn: TextView
    private fun d(v: Int) = Ui.dp(this, v)
    private fun col(id: Int) = getColor(id)

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", data))
            Toast.makeText(this, "الفقاعة تعمل. افتح تطبيق القراءة", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        Dict.seed(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(28), d(20), d(32)) }

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(d(18), d(18), d(18), d(18))
            background = Ui.round(Ui.ACCENT, d(24).toFloat())
            layoutParams = LinearLayout.LayoutParams(d(72), d(72))
        })
        root.addView(TextView(this).apply {
            text = "مترجم المانهوا"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(col(R.color.text)); setPadding(0, d(14), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "ترجمة فورية فوق المانهوا والمانغا"; textSize = 15f
            setTextColor(col(R.color.subtext)); setPadding(0, d(4), 0, d(8))
        })

        val status = Ui.card(this, "الحالة")
        statusTv = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, d(4), 0, 0) }
        permTv = Ui.note(this, "")
        toggleBtn = Ui.btn(this, "")
        status.addView(statusTv); status.addView(permTv); status.addView(toggleBtn)
        root.addView(status)

        val steps = Ui.card(this, "طريقة الاستخدام")
        listOf(
            "نزّل لغات الترجمة من الإعدادات مرة واحدة، وهذا يحتاج إنترنت.",
            "شغّل الفقاعة وامنح الصلاحيات المطلوبة.",
            "افتح تطبيق المانهوا، واضغط 👁 للترجمة مرة، أو ▶ للترجمة المستمرة."
        ).forEachIndexed { i, text -> steps.addView(Ui.note(this, "${i + 1}. $text")) }
        root.addView(steps)

        root.addView(TextView(this).apply {
            text = "نسخة البناء: mask-7"; textSize = 12f; gravity = android.view.Gravity.CENTER
            setTextColor(col(R.color.subtext)); setPadding(0, d(16), 0, 0)
        })
        root.addView(Ui.btn(this, "الإعدادات", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(col(R.color.bg)); addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val running = Prefs.p(this).getBoolean("running", false)
        statusTv.text = if (running) "● الفقاعة تعمل" else "○ الفقاعة متوقفة"
        statusTv.setTextColor(if (running) 0xFF2EB67D.toInt() else col(R.color.subtext))
        permTv.text = if (Settings.canDrawOverlays(this)) "✓ صلاحية العرض فوق التطبيقات ممنوحة"
        else "✗ تحتاج صلاحية العرض فوق التطبيقات"
        toggleBtn.text = if (running) "إيقاف الفقاعة" else "تشغيل الفقاعة"
        toggleBtn.background = Ui.round(if (running) 0xFFFF3B30.toInt() else Ui.ACCENT, 40f)
        toggleBtn.setOnClickListener { if (running) stopBubble() else start() }
    }

    private fun stopBubble() {
        startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        toggleBtn.postDelayed({ refresh() }, 400)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        capture.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}
