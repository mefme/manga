package com.example.mangatrans

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Color
import android.graphics.Typeface
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.ImageView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.ArrayAdapter
import android.widget.EditText
import android.widget.Spinner
import android.view.Gravity
import android.text.Editable
import android.text.TextWatcher
import android.widget.AdapterView
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import com.google.mlkit.nl.languageid.LanguageIdentification
import android.content.ClipData
import android.content.ClipboardManager
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.nl.translate.TranslateLanguage
import com.google.mlkit.nl.translate.Translation
import com.google.mlkit.nl.translate.TranslatorOptions
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import java.util.Locale
import android.widget.TextView
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts

class MainActivity : ComponentActivity() {
    private lateinit var statusTv: TextView
    private lateinit var permTv: TextView
    private lateinit var toggleBtn: TextView
    private fun d(v: Int) = Ui.dp(this, v)
    private fun col(id: Int) = getColor(id)

    private val capture = registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { r ->
        val data = r.data
        if (r.resultCode == RESULT_OK && data != null) {
            startForegroundService(Intent(this, OverlayService::class.java)
                .putExtra("code", r.resultCode).putExtra("data", data))
            Toast.makeText(this, "الفقاعة تعمل. افتح تطبيق القراءة", Toast.LENGTH_LONG).show()
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        Dict.seed(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(20), d(28), d(20), d(32)) }

        root.addView(ImageView(this).apply {
            setImageResource(R.drawable.ic_translate); setColorFilter(Color.WHITE)
            setPadding(d(18), d(18), d(18), d(18))
            background = Ui.round(Ui.ACCENT, d(24).toFloat())
            layoutParams = LinearLayout.LayoutParams(d(72), d(72))
        })
        root.addView(TextView(this).apply {
            text = "مترجم المانهوا"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(col(R.color.text)); setPadding(0, d(14), 0, 0)
        })
        root.addView(TextView(this).apply {
            text = "ترجمة فورية فوق المانهوا والمانغا"; textSize = 15f
            setTextColor(col(R.color.subtext)); setPadding(0, d(4), 0, d(8))
        })

        val status = Ui.card(this, "الحالة")
        statusTv = TextView(this).apply { textSize = 16f; typeface = Typeface.DEFAULT_BOLD; setPadding(0, d(4), 0, 0) }
        permTv = Ui.note(this, "")
        toggleBtn = Ui.btn(this, "")
        status.addView(statusTv); status.addView(permTv); status.addView(toggleBtn)
        root.addView(status)
        root.addView(translateCard())

        val steps = Ui.card(this, "طريقة الاستخدام")
        listOf(
            "نزّل لغات الترجمة من الإعدادات مرة واحدة، وهذا يحتاج إنترنت.",
            "شغّل الفقاعة وامنح الصلاحيات المطلوبة.",
            "افتح تطبيق المانهوا، واضغط 👁 للترجمة مرة، أو ▶ للترجمة المستمرة."
        ).forEachIndexed { i, text -> steps.addView(Ui.note(this, "${i + 1}. $text")) }
        root.addView(steps)

        root.addView(TextView(this).apply {
            text = "نسخة البناء: tr-14"; textSize = 12f; gravity = android.view.Gravity.CENTER
            setTextColor(col(R.color.subtext)); setPadding(0, d(16), 0, 0)
        })
        root.addView(Ui.btn(this, "الإعدادات", false).apply {
            setOnClickListener { startActivity(Intent(this@MainActivity, SettingsActivity::class.java)) }
        })
        setContentView(ScrollView(this).apply { setBackgroundColor(col(R.color.bg)); addView(root) })
    }

    override fun onResume() { super.onResume(); refresh() }

    private fun refresh() {
        val running = Prefs.p(this).getBoolean("running", false)
        statusTv.text = if (running) "● الفقاعة تعمل" else "○ الفقاعة متوقفة"
        statusTv.setTextColor(if (running) 0xFF2EB67D.toInt() else col(R.color.subtext))
        permTv.text = if (Settings.canDrawOverlays(this)) "✓ صلاحية العرض فوق التطبيقات ممنوحة"
        else "✗ تحتاج صلاحية العرض فوق التطبيقات"
        toggleBtn.text = if (running) "إيقاف الفقاعة" else "تشغيل الفقاعة"
        toggleBtn.background = Ui.round(if (running) 0xFFFF3B30.toInt() else Ui.ACCENT, 40f)
        toggleBtn.setOnClickListener { if (running) stopBubble() else start() }
    }

    private fun langName(code: String) =
        if (code == "auto") "اكتشاف تلقائي" else Locale(code).getDisplayName(Locale("ar")).ifBlank { code }

    /** ترجمة نص داخل التطبيق: تُترجم تلقائياً أثناء الكتابة أو اللصق، مع اكتشاف اللغة. */
    private fun translateCard(): LinearLayout {
        val c = Ui.card(this, "ترجمة نص")
        val all = TranslateLanguage.getAllLanguages().sortedBy { langName(it) }
        val codes = listOf("auto") + all
        val langAdapter = ArrayAdapter(this, android.R.layout.simple_spinner_dropdown_item, codes.map { langName(it) })
        val from = Spinner(this).apply { this.adapter = langAdapter; setSelection(0) }
        val to = Spinner(this).apply { this.adapter = langAdapter; setSelection(codes.indexOf(TranslateLanguage.ENGLISH)) }
        val input = EditText(this).apply { hint = "اكتب أو الصق النص هنا"; minLines = 3; gravity = Gravity.TOP or Gravity.START }
        val detected = Ui.note(this, "")
        val placeholder = "الترجمة تظهر هنا"
        val output = TextView(this).apply {
            textSize = 18f; setTextIsSelectable(true); setTextColor(col(R.color.text))
            setPadding(d(14), d(12), d(14), d(12))
            background = Ui.round(col(R.color.bg), 20f)
            text = placeholder
            layoutParams = LinearLayout.LayoutParams(-1, -2).apply { topMargin = d(12) }
        }
        var lastDetected: String? = null
        var job: Job? = null

        suspend fun doTranslate() {
            val text = input.text.toString().trim()
            if (text.isEmpty()) { output.text = placeholder; detected.text = ""; return }
            val tgt = codes[to.selectedItemPosition]
            var src = codes[from.selectedItemPosition]
            try {
                if (src == "auto") {
                    val id = LanguageIdentification.getClient().identifyLanguage(text).await()
                    if (id == "und") { output.text = "تعذّر تحديد اللغة"; detected.text = ""; return }
                    src = id; lastDetected = id
                    detected.text = "اللغة المكتشفة: ${langName(id)}"
                } else detected.text = ""
                if (src == tgt) { output.text = text; return }
                val client = Translation.getClient(
                    TranslatorOptions.Builder().setSourceLanguage(src).setTargetLanguage(tgt).build())
                client.downloadModelIfNeeded().await()
                output.text = client.translate(text).await()
                client.close()
            } catch (e: Exception) {
                output.text = "تعذّرت الترجمة. تأكد من الإنترنت لتحميل اللغات مرة واحدة."
            }
        }

        fun schedule() {
            job?.cancel()
            job = lifecycleScope.launch { delay(450); doTranslate() }
        }

        val listener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(p: AdapterView<*>?, v: View?, pos: Int, id: Long) { schedule() }
            override fun onNothingSelected(p: AdapterView<*>?) {}
        }
        from.onItemSelectedListener = listener
        to.onItemSelectedListener = listener
        input.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, cnt: Int) {}
            override fun afterTextChanged(s: Editable?) { schedule() }
        })

        val swap = ImageView(this).apply {
            setImageResource(R.drawable.ic_swap); setColorFilter(col(R.color.text))
            setPadding(d(10), d(10), d(10), d(10))
            layoutParams = LinearLayout.LayoutParams(d(44), d(44))
            setOnClickListener {
                val s = from.selectedItemPosition; val t = to.selectedItemPosition
                val newTo = if (s == 0) codes.indexOf(lastDetected ?: TranslateLanguage.ARABIC) else s
                from.setSelection(t); to.setSelection(newTo)
                val out = output.text.toString()
                if (out.isNotEmpty() && out != placeholder) input.setText(out)
            }
        }
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(from, LinearLayout.LayoutParams(0, -2, 1f))
            addView(swap)
            addView(to, LinearLayout.LayoutParams(0, -2, 1f))
        }
        output.setOnClickListener {
            val text = output.text.toString()
            if (text.isNotEmpty() && text != placeholder) {
                getSystemService(ClipboardManager::class.java).setPrimaryClip(ClipData.newPlainText("ترجمة", text))
                Toast.makeText(this, "تم النسخ", Toast.LENGTH_SHORT).show()
            }
        }
        c.addView(row)
        c.addView(input)
        c.addView(detected)
        c.addView(output)
        c.addView(Ui.note(this, "اضغط على الترجمة لنسخها"))
        return c
    }

    private fun stopBubble() {
        startService(Intent(this, OverlayService::class.java).setAction(OverlayService.ACTION_STOP))
        toggleBtn.postDelayed({ refresh() }, 400)
    }

    private fun start() {
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "فعّل «العرض فوق التطبيقات» ثم ارجع", Toast.LENGTH_LONG).show()
            return
        }
        if (Build.VERSION.SDK_INT >= 33 &&
            checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED)
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 1)
        capture.launch(getSystemService(MediaProjectionManager::class.java).createScreenCaptureIntent())
    }
}
