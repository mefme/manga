package com.example.mangatrans

import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.*
import androidx.activity.ComponentActivity
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.widget.doAfterTextChanged
import androidx.lifecycle.lifecycleScope
import com.google.mlkit.common.model.DownloadConditions
import com.google.mlkit.common.model.RemoteModelManager
import com.google.mlkit.nl.translate.TranslateRemoteModel
import kotlinx.coroutines.launch
import kotlinx.coroutines.tasks.await
import org.json.JSONObject

class SettingsActivity : ComponentActivity() {
    private val p by lazy { Prefs.p(this) }
    private lateinit var dictList: LinearLayout
    private lateinit var fromEt: EditText
    private lateinit var toEt: EditText
    private lateinit var countTv: TextView
    private var filter = ""
    private fun d(v: Int) = Ui.dp(this, v)
    private fun col(id: Int) = getColor(id)
    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    private val exportLauncher = registerForActivityResult(
        ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri != null) {
            contentResolver.openOutputStream(uri)?.use { it.write(Dict.toJson(Dict.load(this)).toString(2).toByteArray()) }
            toast("تم تصدير القاموس")
        }
    }
    private val importLauncher = registerForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            try {
                val text = contentResolver.openInputStream(uri)!!.bufferedReader().use { it.readText() }
                val o = JSONObject(text)
                val m = Dict.load(this)
                o.keys().forEach { k -> m[k] = o.getString(k) }
                Dict.save(this, m); refreshDict()
                toast("تم استيراد القاموس")
            } catch (e: Exception) { toast("الملف غير صالح") }
        }
    }

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        window.decorView.layoutDirection = View.LAYOUT_DIRECTION_RTL
        Dict.seed(this)
        val root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(d(16), d(20), d(16), d(40)) }
        root.addView(TextView(this).apply {
            text = "الإعدادات"; textSize = 28f; typeface = Typeface.DEFAULT_BOLD; setTextColor(col(R.color.text))
        })
        langCard(root); fontCard(root); colorCard(root); bubbleCard(root); engineCard(root); modelsCard(root); dictCard(root)
        setContentView(ScrollView(this).apply { setBackgroundColor(col(R.color.bg)); addView(root) })
    }

    private fun label(t: String) = TextView(this).apply {
        text = t; textSize = 14f; setTextColor(col(R.color.subtext)); setPadding(0, d(10), 0, d(2))
    }

    private fun spinner(m: Map<String, String>, key: String, def: String) = Spinner(this).apply {
        val keys = m.keys.toList()
        adapter = ArrayAdapter(this@SettingsActivity, android.R.layout.simple_spinner_dropdown_item, m.values.toList())
        setSelection(keys.indexOf(p.getString(key, def)).coerceAtLeast(0))
        onItemSelectedListener = object : AdapterView.OnItemSelectedListener {
            override fun onItemSelected(a: AdapterView<*>?, v: View?, i: Int, id: Long) { p.edit().putString(key, keys[i]).apply() }
            override fun onNothingSelected(a: AdapterView<*>?) {}
        }
    }

    private fun radios(opts: List<String>, key: String, def: Int, horizontal: Boolean) = RadioGroup(this).apply {
        orientation = if (horizontal) RadioGroup.HORIZONTAL else RadioGroup.VERTICAL
        val ids = opts.map { o ->
            RadioButton(this@SettingsActivity).apply { text = o; id = View.generateViewId() }.also { addView(it) }.id
        }
        check(ids[p.getInt(key, def).coerceIn(0, ids.size - 1)])
        setOnCheckedChangeListener { _, id -> p.edit().putInt(key, ids.indexOf(id)).apply() }
    }

    private fun langCard(root: LinearLayout) {
        val c = Ui.card(this, "اللغة")
        c.addView(label("لغة النص الأصلي"))
        c.addView(spinner(Prefs.sources, "src", "auto"))
        c.addView(label("الترجمة إلى"))
        c.addView(spinner(Prefs.targets, "tgt", "ar"))
        root.addView(c)
    }

    private fun fontCard(root: LinearLayout) {
        val c = Ui.card(this, "حجم خط الترجمة")
        val names = listOf("صغير", "متوسط", "كبير", "كبيرة جداً")
        c.addView(sliderRow("الحجم", "size", 0, 3, 1) { names[it] })
        root.addView(c)
    }

    private fun colorCard(root: LinearLayout) {
        val c = Ui.card(this, "لون خط الترجمة")
        c.addView(Ui.note(this, "«A» = تلقائي: يطابق لون النص الأصلي. مرّر يميناً ويساراً لرؤية كل الألوان."))
        val options = listOf(0, 0xFF000000.toInt(), 0xFFFFFFFF.toInt(), 0xFFFFD60A.toInt(),
            0xFFFF3B30.toInt(), 0xFF0A84FF.toInt(), 0xFF2EB67D.toInt(), 0xFFFF9F0A.toInt())
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        fun draw() {
            row.removeAllViews()
            val cur = p.getInt("color", 0)
            options.forEach { cv ->
                row.addView(TextView(this).apply {
                    text = if (cv == 0) "A" else ""; gravity = Gravity.CENTER; textSize = 16f; setTextColor(Color.BLACK)
                    background = GradientDrawable().apply {
                        shape = GradientDrawable.OVAL
                        setColor(if (cv == 0) 0xFFE0E3F0.toInt() else cv)
                        setStroke(if (cur == cv) 8 else 2, if (cur == cv) Ui.ACCENT else 0xFFBBBBBB.toInt())
                    }
                    layoutParams = LinearLayout.LayoutParams(d(46), d(46)).apply { marginEnd = d(12) }
                    setOnClickListener { p.edit().putInt("color", cv).apply(); draw() }
                })
            }
        }
        draw()
        c.addView(HorizontalScrollView(this).apply { isHorizontalScrollBarEnabled = false; addView(row) })
        root.addView(c)
    }

    private fun bubbleCard(root: LinearLayout) {
        val c = Ui.card(this, "الفقاعة العائمة")
        c.addView(sliderRow("حجم الفقاعة", "bscale", 60, 140, 100) { "$it%" })
        c.addView(sliderRow("شفافية الفقاعة", "balpha2", 20, 100, 100) { "$it%" })
        c.addView(Ui.note(this, "يطبّق التغيير عند تشغيل الفقاعة من جديد."))
        root.addView(c)
    }

    /** شريط تمرير بقيمة ظاهرة: مثلاً النسبة المئوية أو اسم الحجم. */
    private fun sliderRow(title: String, key: String, lo: Int, hi: Int, def: Int, fmt: (Int) -> String): LinearLayout {
        val value = TextView(this).apply { textSize = 14f; setTextColor(col(R.color.subtext)) }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            addView(TextView(this@SettingsActivity).apply {
                text = title; textSize = 15f; setTextColor(col(R.color.text))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            })
            addView(value)
        }
        val cur = p.getInt(key, def).coerceIn(lo, hi)
        value.text = fmt(cur)
        val seek = SeekBar(this).apply {
            max = hi - lo; progress = cur - lo
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, pr: Int, fromUser: Boolean) {
                    val v = pr + lo
                    value.text = fmt(v)
                    if (fromUser) p.edit().putInt(key, v).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        return LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL; setPadding(0, d(8), 0, d(6))
            addView(head); addView(seek)
        }
    }

    private fun engineCard(root: LinearLayout) {
        val c = Ui.card(this, "محرك الترجمة")
        c.addView(radios(listOf(
            "على الجهاز (بدون إنترنت، أسرع)",
            "عبر الإنترنت (دقة أعلى، Google Cloud)",
            "تلقائي: الإنترنت إن توفر وإلا على الجهاز"), "engine", 2, false))
        c.addView(EditText(this).apply {
            hint = "مفتاح Google Cloud Translation API"; setText(p.getString("apikey", ""))
            setSingleLine(); doAfterTextChanged { p.edit().putString("apikey", it.toString()).apply() }
        })
        c.addView(Ui.note(this, "الترجمة عبر الإنترنت تحتاج مفتاح API من Google Cloud (console.cloud.google.com)، وتفعيل الفوترة مع حصة مجانية شهرية. بدون مفتاح أو عند انقطاع الإنترنت تعمل الترجمة على الجهاز."))
        root.addView(c)
    }

    private fun modelsCard(root: LinearLayout) {
        val c = Ui.card(this, "اللغات دون إنترنت")
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(Ui.note(this, "حمّل اللغة المصدر واللغة الهدف (مثلاً: الإنجليزية + العربية) لتعمل الترجمة بسرعة وبدون إنترنت."))
        val mgr = RemoteModelManager.getInstance()
        val names = LinkedHashMap<String, String>().apply {
            putAll(Prefs.targets); Prefs.sources.forEach { if (it.key != "auto") putIfAbsent(it.key, it.value) }
        }
        names.forEach { (code, name) ->
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL; setPadding(0, d(6), 0, d(6)) }
            val label = TextView(this).apply {
                text = name; textSize = 16f; setTextColor(col(R.color.text))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
            }
            val b = TextView(this).apply { textSize = 14f; setPadding(d(14), d(8), d(14), d(8)); setTextColor(Color.WHITE) }
            val model = TranslateRemoteModel.Builder(code).build()
            fun refresh() {
                lifecycleScope.launch {
                    val ok = try { mgr.isModelDownloaded(model).await() } catch (e: Exception) { false }
                    b.text = if (ok) "✓ محمّلة · حذف" else "تحميل"
                    b.background = Ui.round(if (ok) 0xFF2EB67D.toInt() else Ui.ACCENT, 40f)
                    b.setOnClickListener {
                        lifecycleScope.launch {
                            b.text = "جارٍ..."
                            try {
                                if (ok) mgr.deleteDownloadedModel(model).await()
                                else mgr.download(model, DownloadConditions.Builder().build()).await()
                            } catch (e: Exception) { toast("فشل: تحقق من الإنترنت") }
                            refresh()
                        }
                    }
                }
            }
            refresh()
            row.addView(label); row.addView(b); body.addView(row)
        }
        c.addView(Ui.drawer(this, "عرض اللغات", body))
        root.addView(c)
    }

    private fun dictCard(root: LinearLayout) {
        val c = Ui.card(this, "القاموس المخصص")
        c.addView(Ui.note(this, "يستبدل كلمات في الترجمة العربية بما تريد. اضغط على عبارة لتعديلها، أو ✕ لحذفها."))
        fromEt = EditText(this).apply { hint = "الكلمة في الترجمة (مثال: إله)" }
        toEt = EditText(this).apply { hint = "البديل (مثال: حاكم)" }
        c.addView(fromEt); c.addView(toEt)
        c.addView(Ui.btn(this, "إضافة / تحديث").apply {
            setOnClickListener {
                val a = fromEt.text.toString().trim(); val b = toEt.text.toString().trim()
                if (a.isNotEmpty() && b.isNotEmpty()) {
                    val m = Dict.load(this@SettingsActivity); m[a] = b; Dict.save(this@SettingsActivity, m)
                    fromEt.text.clear(); toEt.text.clear(); refreshDict()
                }
            }
        })
        c.addView(Ui.btn(this, "إضافة القاموس الجاهز (الشرك والعبادة)", false).apply {
            setOnClickListener { addPreset(Presets.core) }
        })
        c.addView(Ui.btn(this, "إضافة مجموعة السحر (اختيارية)", false).apply {
            setOnClickListener { addPreset(Presets.magic) }
        })
        c.addView(Ui.btn(this, "تصدير القاموس (ملف)", false).apply {
            setOnClickListener { exportLauncher.launch("قاموس-المانهوا.json") }
        })
        c.addView(Ui.btn(this, "استيراد قاموس (ملف)", false).apply {
            setOnClickListener { importLauncher.launch(arrayOf("application/json", "text/*")) }
        })
        c.addView(Ui.btn(this, "حذف كل العبارات", false).apply {
            setOnClickListener {
                AlertDialog.Builder(this@SettingsActivity).setMessage("حذف كل العبارات؟")
                    .setPositiveButton("حذف") { _, _ -> Dict.save(this@SettingsActivity, emptyMap()); refreshDict() }
                    .setNegativeButton("إلغاء", null).show()
            }
        })
        countTv = Ui.note(this, "")
        c.addView(countTv)
        val body = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(EditText(this).apply {
            hint = "بحث في العبارات"; setSingleLine()
            doAfterTextChanged { filter = it.toString().trim(); refreshDict() }
        })
        dictList = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        body.addView(dictList)
        c.addView(Ui.drawer(this, "العبارات المحفوظة", body))
        root.addView(c)
        refreshDict()
    }

    private fun addPreset(preset: Map<String, String>) {
        val m = Dict.load(this)
        var n = 0
        preset.forEach { (k, v) -> if (!m.containsKey(k)) { m[k] = v; n++ } }
        Dict.save(this, m); refreshDict()
        toast("أُضيفت $n عبارة")
    }

    private fun refreshDict() {
        dictList.removeAllViews()
        val all = Dict.load(this)
        countTv.text = "عدد العبارات: ${all.size}"
        for ((k, v) in all) {
            if (filter.isNotEmpty() && !k.contains(filter) && !v.contains(filter)) continue
            val row = LinearLayout(this).apply { gravity = Gravity.CENTER_VERTICAL }
            row.addView(TextView(this).apply {
                text = "$k  ←  $v"; textSize = 17f; setPadding(0, d(8), 0, d(8))
                setTextColor(col(R.color.text))
                layoutParams = LinearLayout.LayoutParams(0, -2, 1f)
                setOnClickListener { fromEt.setText(k); toEt.setText(v) }
            })
            row.addView(TextView(this).apply {
                text = "✕"; textSize = 18f; setTextColor(0xFFFF3B30.toInt()); setPadding(d(14), d(8), d(14), d(8))
                setOnClickListener { val m = Dict.load(this@SettingsActivity); m.remove(k); Dict.save(this@SettingsActivity, m); refreshDict() }
            })
            dictList.addView(row)
        }
    }
}
