package com.example.mangatrans

import android.content.Context
import android.graphics.*
import android.text.Layout
import android.text.StaticLayout
import android.text.TextDirectionHeuristics
import android.text.TextPaint
import android.view.View

class Item(val box: RectF, val text: String, val fg: Int, val scale: Float, val halo: Int, val lineH: Float)

/** يرسم خلفية مصمتة فوق كل فقاعة (تُخفي النص الأصلي كاملاً) ثم نص الترجمة فوقها. */
class TranslationOverlayView(c: Context) : View(c) {
    private var patch: Bitmap? = null
    private var items: List<Item> = emptyList()
    private val tp = TextPaint(Paint.ANTI_ALIAS_FLAG).apply { typeface = Typeface.DEFAULT_BOLD }
    private val bgp = Paint(Paint.ANTI_ALIAS_FLAG)

    fun show(p: Bitmap?, l: List<Item>) { patch = p; items = l; invalidate() }
    fun clear() = show(null, emptyList())
    fun hasItems() = patch != null

    private fun layout(t: String, w: Int) = StaticLayout.Builder.obtain(t, 0, t.length, tp, w)
        .setAlignment(Layout.Alignment.ALIGN_CENTER)
        .setTextDirection(TextDirectionHeuristics.RTL).build()

    override fun onDraw(c: Canvas) {
        patch?.let { c.drawBitmap(it, 0f, 0f, null) }
        for (m in items) {
            val bw = (m.box.width() + 24f).coerceAtLeast(160f)
            val tw = bw.toInt()
            // حجم أولي حسب سطر النص والمقياس، ثم تصغير حتى يدخل النص الفقاعة
            var size = (m.lineH * 0.95f * m.scale).coerceIn(14f, 110f)
            var sl: StaticLayout
            do {
                tp.textSize = size
                sl = layout(m.text, tw)
                size -= 2f
            } while (sl.height > m.box.height() * 1.5f && size > 12f)
            val fs = size + 2f
            tp.textSize = fs
            sl = layout(m.text, tw)
            val hh = maxOf(sl.height.toFloat(), m.box.height())
            val cx = m.box.centerX(); val cy = m.box.centerY()
            bgp.color = m.halo
            c.drawRoundRect(RectF(cx - bw / 2 - 4, cy - hh / 2 - 4, cx + bw / 2 + 4, cy + hh / 2 + 4), 14f, 14f, bgp)
            c.save()
            c.translate(cx - bw / 2, cy - sl.height / 2f)
            tp.style = Paint.Style.FILL; tp.color = m.fg
            sl.draw(c)
            c.restore()
        }
    }
}
