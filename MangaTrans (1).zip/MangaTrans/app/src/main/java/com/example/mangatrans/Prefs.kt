package com.example.mangatrans

import android.content.Context
import com.google.mlkit.nl.translate.TranslateLanguage
import java.util.Locale

object Prefs {
    fun p(c: Context) = c.getSharedPreferences("p", 0)

    fun langName(code: String): String =
        if (code == "auto") "تلقائي" else Locale(code).getDisplayName(Locale("ar")).ifBlank { code }

    /** الترتيب: الإنجليزية، العربية، اليابانية، الصينية، الكورية، ثم باقي اللغات حسب الاسم. */
    val allCodes: List<String> by lazy {
        val top = listOf("en", "ar", "ja", "zh", "ko")
        top + TranslateLanguage.getAllLanguages().filter { it !in top }.sortedBy { langName(it) }
    }

    /** لغة النص الأصلي (للتقاط الشاشة): تلقائي ثم كل اللغات. */
    val sources: LinkedHashMap<String, String> by lazy {
        LinkedHashMap<String, String>().apply {
            put("auto", "تلقائي")
            allCodes.forEach { put(it, langName(it)) }
        }
    }

    /** لغة الترجمة: كل اللغات بالترتيب نفسه. */
    val targets: LinkedHashMap<String, String> by lazy {
        LinkedHashMap<String, String>().apply { allCodes.forEach { put(it, langName(it)) } }
    }
}
