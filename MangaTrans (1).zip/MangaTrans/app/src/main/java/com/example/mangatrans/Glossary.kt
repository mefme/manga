package com.example.mangatrans

/** عبارات إنجليزية شائعة في المانهوا بترجمة جاهزة، تُستخدم قبل محرك الترجمة. */
object Glossary {
    private val en = mapOf(
        "hi" to "مرحباً", "hello" to "مرحباً", "hey" to "يا", "thanks" to "شكراً",
        "thank you" to "شكراً لك", "thank you so much" to "شكراً جزيلاً لك",
        "i'm sorry" to "أنا آسف", "sorry" to "آسف", "please" to "من فضلك",
        "yes" to "نعم", "no" to "لا", "what" to "ماذا", "what?" to "ماذا؟",
        "why" to "لماذا", "why?" to "لماذا؟", "how?" to "كيف؟", "where?" to "أين؟",
        "oh my god" to "يا إلهي", "oh god" to "يا إلهي", "oh no" to "يا للهول",
        "wait" to "انتظر", "wait!" to "انتظر!", "stop" to "توقف", "come here" to "تعال إلى هنا",
        "let's go" to "هيا بنا", "good" to "جيد", "good morning" to "صباح الخير",
        "good night" to "تصبح على خير", "goodbye" to "وداعاً", "help" to "النجدة",
        "help me" to "ساعدني", "run!" to "اهرب!", "no way" to "مستحيل", "impossible" to "مستحيل",
        "really?" to "حقاً؟", "is that so?" to "أهذا صحيح؟", "i see" to "فهمت",
        "i know" to "أعرف", "i don't know" to "لا أعرف", "who are you?" to "من أنت؟",
        "what do you want?" to "ماذا تريد؟", "get out" to "اخرج", "idiot" to "أحمق",
        "you idiot" to "أيها الأحمق", "damn it" to "اللعنة", "shut up" to "اخرس",
        "of course" to "بالطبع", "your majesty" to "جلالتك", "your highness" to "سموك",
        "what the hell?" to "ما هذا بحق الجحيم؟", "are you okay?" to "هل أنت بخير؟",
        "i'm fine" to "أنا بخير", "let me go" to "دعني أذهب", "don't go" to "لا تذهب",
        "it's okay" to "لا بأس", "i'm home" to "عدت إلى البيت", "i'm back" to "عدت"
    )

    /** يعيد الترجمة الجاهزة إن وُجدت، وإلا null. */
    fun lookup(text: String, src: String, tgt: String): String? {
        if (src != "en" || tgt != "ar") return null
        val apos = '\u2019'
        val key = text.lowercase().replace(apos, '\'').replace(Regex("\\s+"), " ").trim()
        val bare = key.trimEnd('.', '!', '?', '\u2026', ' ')
        return en[key] ?: en[bare] ?: en[bare + "?"]
    }
}
